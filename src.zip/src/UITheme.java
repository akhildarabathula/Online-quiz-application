import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 * UITheme.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Custom Graphics2D Rendering & Method Overriding ('paintComponent' / 'paintBorder'):
 *    Uses 'Graphics2D' with 'RenderingHints.KEY_ANTIALIASING' to draw smooth 16px rounded
 *    cards (RoundedPanel), 10px rounded hover-animated buttons (ModernButton), focus-ring
 *    inputs (ModernTextField / ModernPasswordField), and clickable MCQ cards (OptionCard).
 * 2. Inner Classes & Inheritance:
 *    Demonstrates extending JPanel, JButton, JTextField, and JPasswordField to build a
 *    reusable SaaS design system (inspired by Linear, Notion, and HackerRank) in pure Java Swing.
 */
public class UITheme {

    // ==================== 2026 SAAS COLOR PALETTE ====================
    public static final Color BG_CANVAS          = new Color(248, 250, 252); // #F8FAFC App Canvas
    public static final Color BG_CARD            = new Color(255, 255, 255); // #FFFFFF Elevated Card
    public static final Color BG_SUBTLE          = new Color(241, 245, 249); // #F1F5F9 Muted Surface
    public static final Color BORDER_CARD        = new Color(226, 232, 240); // #E2E8F0 1px Card Border
    public static final Color BORDER_INPUT       = new Color(203, 213, 225); // #CBD5E1 Input Border

    public static final Color ACCENT_INDIGO      = new Color(79, 70, 229);   // #4F46E5 Primary Brand
    public static final Color ACCENT_INDIGO_HOVER= new Color(67, 56, 202);   // #4338CA Primary Hover
    public static final Color ACCENT_INDIGO_SOFT = new Color(238, 242, 255); // #EEF2FF Soft Indigo Tint
    public static final Color ACCENT_INDIGO_BDR  = new Color(165, 180, 252); // #A5B4FC Selected Card Border

    public static final Color TEXT_PRIMARY       = new Color(15, 23, 42);    // #0F172A Deep Slate
    public static final Color TEXT_SECONDARY     = new Color(51, 65, 85);    // #334155 Medium Slate
    public static final Color TEXT_MUTED         = new Color(100, 116, 139); // #64748B Muted Slate

    public static final Color SUCCESS_GREEN      = new Color(16, 185, 129);  // #10B981 Emerald
    public static final Color SUCCESS_HOVER      = new Color(5, 150, 105);   // #059669 Emerald Hover
    public static final Color SUCCESS_SOFT_BG    = new Color(236, 253, 245); // #ECFDF5 Soft Green Tint
    public static final Color SUCCESS_BORDER     = new Color(110, 231, 183); // #6EE7B7 Soft Green Border

    public static final Color DANGER_RED         = new Color(239, 68, 68);   // #EF4444 Crimson
    public static final Color DANGER_HOVER       = new Color(220, 38, 38);   // #DC2626 Crimson Hover
    public static final Color DANGER_SOFT_BG     = new Color(254, 242, 242); // #FEF2F2 Soft Red Tint
    public static final Color DANGER_BORDER      = new Color(252, 165, 165); // #FCA5A5 Soft Red Border

    public static final Color WARNING_AMBER      = new Color(245, 158, 11);  // #F59E0B Amber
    public static final Color WARNING_SOFT_BG    = new Color(254, 243, 199); // #FEF3C7 Soft Amber

    // Backward-compatible aliases
    public static final Color BG_MAIN            = BG_CANVAS;
    public static final Color BORDER_SUBTLE      = BORDER_CARD;
    public static final Color ACCENT_PRIMARY     = ACCENT_INDIGO;
    public static final Color ACCENT_SUCCESS     = SUCCESS_GREEN;
    public static final Color ACCENT_DANGER      = DANGER_RED;
    public static final Color ACCENT_SLATE       = TEXT_MUTED;
    public static final Color TEXT_DARK          = TEXT_PRIMARY;
    public static final Color SOFT_GREEN_BG      = SUCCESS_SOFT_BG;
    public static final Color SOFT_GREEN_BORDER  = SUCCESS_BORDER;
    public static final Color SOFT_RED_BG        = DANGER_SOFT_BG;
    public static final Color SOFT_RED_BORDER    = DANGER_BORDER;
    public static final Color SOFT_INDIGO_BG     = ACCENT_INDIGO_SOFT;

    // ==================== TYPOGRAPHY HIERARCHY ====================
    public static final Font FONT_HERO     = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_SECTION  = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_HEADING  = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_BODY_LG  = new Font("Segoe UI", Font.PLAIN, 16);
    public static final Font FONT_BOLD     = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font FONT_BODY     = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BADGE    = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_SMALL    = new Font("Segoe UI", Font.PLAIN, 12);

    // Standard Minimum Window Dimension (1100 x 750)
    public static final Dimension WINDOW_DIMENSION = new Dimension(1120, 760);

    /**
     * Configures global Swing UIManager defaults for clean SaaS rendering.
     */
    public static void applyGlobalTheme() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            UIManager.put("Panel.background", BG_CANVAS);
            UIManager.put("OptionPane.background", BG_CARD);
            UIManager.put("OptionPane.messageForeground", TEXT_PRIMARY);
            UIManager.put("OptionPane.messageFont", FONT_BODY);
            UIManager.put("OptionPane.buttonFont", FONT_BOLD);
            UIManager.put("ComboBox.background", BG_CARD);
            UIManager.put("ComboBox.foreground", TEXT_PRIMARY);
            UIManager.put("ComboBox.selectionBackground", ACCENT_INDIGO_SOFT);
            UIManager.put("ComboBox.selectionForeground", ACCENT_INDIGO);
            UIManager.put("ComboBox.font", FONT_BODY);
            UIManager.put("ScrollPane.background", BG_CANVAS);
        } catch (Exception e) {
            System.out.println("Theme initialization note: " + e.getMessage());
        }
    }

    // =========================================================================
    // CUSTOM COMPONENT 1: RoundedPanel (16px Anti-Aliased Card Surface)
    // =========================================================================

    /**
     * VIVA CONCEPT: Method Overriding (paintComponent) with Graphics2D Anti-Aliasing
     * Renders a crisp rounded surface (default 16px corner radius) with a 1px soft border.
     */
    public static class RoundedPanel extends JPanel {
        private int cornerRadius;
        private Color fillColor;
        private Color borderColor;
        private int borderThickness;

        public RoundedPanel(LayoutManager layout, int cornerRadius, Color fillColor, Color borderColor, int topBottomPad, int leftRightPad) {
            super(layout);
            this.cornerRadius = cornerRadius;
            this.fillColor = fillColor;
            this.borderColor = borderColor;
            this.borderThickness = 1;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(topBottomPad, leftRightPad, topBottomPad, leftRightPad));
        }

        public RoundedPanel(LayoutManager layout, int topBottomPad, int leftRightPad) {
            this(layout, 16, BG_CARD, BORDER_CARD, topBottomPad, leftRightPad);
        }

        public void setFillColor(Color fillColor) {
            this.fillColor = fillColor;
            repaint();
        }

        public void setBorderColor(Color borderColor) {
            this.borderColor = borderColor;
            repaint();
        }

        public void setBorderThickness(int borderThickness) {
            this.borderThickness = borderThickness;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();

            // Fill rounded background
            g2.setColor(fillColor);
            g2.fillRoundRect(0, 0, width - 1, height - 1, cornerRadius, cornerRadius);

            // Draw rounded border
            if (borderColor != null && borderThickness > 0) {
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(borderThickness));
                int offset = borderThickness / 2;
                g2.drawRoundRect(offset, offset, width - 1 - borderThickness, height - 1 - borderThickness, cornerRadius, cornerRadius);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // =========================================================================
    // CUSTOM COMPONENT 2: ModernButton (10px Rounded Button with Smooth Hover)
    // =========================================================================

    /**
     * VIVA CONCEPT: Custom JButton with MouseAdapter Hover States & Anti-Aliased Painting
     */
    public static class ModernButton extends JButton {
        private Color normalBg;
        private Color hoverBg;
        private Color textColor;
        private Color borderColor;
        private int radius = 10;
        private boolean isHovered = false;

        public ModernButton(String text, Color normalBg, Color hoverBg, Color textColor, Color borderColor) {
            super(text);
            this.normalBg = normalBg;
            this.hoverBg = hoverBg;
            this.textColor = textColor;
            this.borderColor = borderColor;

            setFont(FONT_BOLD);
            setForeground(textColor);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    if (isEnabled()) {
                        isHovered = true;
                        repaint();
                    }
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    isHovered = false;
                    repaint();
                }
            });
        }

        public void setColors(Color normalBg, Color hoverBg, Color textColor, Color borderColor) {
            this.normalBg = normalBg;
            this.hoverBg = hoverBg;
            this.textColor = textColor;
            this.borderColor = borderColor;
            setForeground(textColor);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            if (!isEnabled()) {
                g2.setColor(new Color(226, 232, 240));
                setForeground(TEXT_MUTED);
            } else {
                g2.setColor(isHovered ? hoverBg : normalBg);
                setForeground(textColor);
            }

            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);

            if (borderColor != null && isEnabled()) {
                g2.setColor(borderColor);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // =========================================================================
    // CUSTOM COMPONENT 3: ModernTextField & ModernPasswordField (Focus Ring)
    // =========================================================================

    /**
     * VIVA CONCEPT: FocusListener (FocusAdapter)
     * Highlights the 10px rounded input border in Royal Indigo (#4F46E5) when focused!
     */
    public static class ModernTextField extends JTextField {
        private boolean focused = false;
        private int radius = 10;

        public ModernTextField(String text, int columns) {
            super(text, columns);
            initStyle();
        }

        public ModernTextField(int columns) {
            super(columns);
            initStyle();
        }

        public ModernTextField() {
            super();
            initStyle();
        }

        private void initStyle() {
            setOpaque(false);
            setFont(FONT_BODY);
            setForeground(TEXT_PRIMARY);
            setCaretColor(ACCENT_INDIGO);
            setPreferredSize(new Dimension(240, 42));
            setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    focused = true;
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    focused = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(BG_CARD);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);

            if (focused) {
                g2.setColor(ACCENT_INDIGO);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, radius, radius);
            } else {
                g2.setColor(BORDER_INPUT);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    /**
     * Custom Rounded Password Field with Indigo Focus Ring.
     */
    public static class ModernPasswordField extends JPasswordField {
        private boolean focused = false;
        private int radius = 10;

        public ModernPasswordField(int columns) {
            super(columns);
            setOpaque(false);
            setFont(FONT_BODY);
            setForeground(TEXT_PRIMARY);
            setCaretColor(ACCENT_INDIGO);
            setPreferredSize(new Dimension(240, 42));
            setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));

            addFocusListener(new FocusAdapter() {
                @Override
                public void focusGained(FocusEvent e) {
                    focused = true;
                    repaint();
                }

                @Override
                public void focusLost(FocusEvent e) {
                    focused = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(BG_CARD);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);

            if (focused) {
                g2.setColor(ACCENT_INDIGO);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, radius, radius);
            } else {
                g2.setColor(BORDER_INPUT);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // =========================================================================
    // CUSTOM COMPONENT 4: OptionCard (Clickable MCQ Choice Card with Badge)
    // =========================================================================

    /**
     * VIVA CONCEPT: Custom Interactive Component (Replaces default JRadioButton)
     * Displays a rounded card with a letter badge ('A', 'B', 'C', 'D') and option text.
     * Highlights with an Indigo border and soft Indigo tint (#EEF2FF) when selected!
     */
    public static class OptionCard extends JPanel {
        private char optionLetter;
        private JLabel letterBadge;
        private JLabel optionTextLabel;
        private boolean selected = false;
        private boolean hovered = false;
        private Runnable onSelectCallback;

        public OptionCard(char optionLetter, Runnable onSelectCallback) {
            super(new BorderLayout(16, 0));
            this.optionLetter = optionLetter;
            this.onSelectCallback = onSelectCallback;

            setOpaque(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

            // Circular/Rounded Letter Badge (A, B, C, D)
            letterBadge = new JLabel(String.valueOf(optionLetter), SwingConstants.CENTER) {
                @Override
                protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    if (selected) {
                        g2.setColor(ACCENT_INDIGO);
                    } else if (hovered) {
                        g2.setColor(new Color(224, 231, 255));
                    } else {
                        g2.setColor(BG_SUBTLE);
                    }
                    g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 10, 10);
                    g2.dispose();
                    super.paintComponent(g);
                }
            };
            letterBadge.setFont(FONT_BOLD);
            letterBadge.setPreferredSize(new Dimension(36, 36));
            letterBadge.setForeground(TEXT_PRIMARY);

            optionTextLabel = new JLabel();
            optionTextLabel.setFont(FONT_BODY_LG);
            optionTextLabel.setForeground(TEXT_PRIMARY);

            add(letterBadge, BorderLayout.WEST);
            add(optionTextLabel, BorderLayout.CENTER);

            MouseAdapter clickAndHover = new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (onSelectCallback != null) {
                        onSelectCallback.run();
                    }
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    hovered = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hovered = false;
                    repaint();
                }
            };

            addMouseListener(clickAndHover);
            letterBadge.addMouseListener(clickAndHover);
            optionTextLabel.addMouseListener(clickAndHover);
        }

        public void setOptionText(String text) {
            optionTextLabel.setText(text);
        }

        public boolean isSelected() {
            return selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
            if (selected) {
                letterBadge.setForeground(Color.WHITE);
                optionTextLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
                optionTextLabel.setForeground(ACCENT_INDIGO);
            } else {
                letterBadge.setForeground(TEXT_SECONDARY);
                optionTextLabel.setFont(FONT_BODY_LG);
                optionTextLabel.setForeground(TEXT_PRIMARY);
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int w = getWidth();
            int h = getHeight();

            if (selected) {
                g2.setColor(ACCENT_INDIGO_SOFT);
                g2.fillRoundRect(0, 0, w - 1, h - 1, 14, 14);
                g2.setColor(ACCENT_INDIGO);
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, 14, 14);
            } else if (hovered) {
                g2.setColor(new Color(248, 250, 252));
                g2.fillRoundRect(0, 0, w - 1, h - 1, 14, 14);
                g2.setColor(ACCENT_INDIGO_BDR);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, 14, 14);
            } else {
                g2.setColor(BG_CARD);
                g2.fillRoundRect(0, 0, w - 1, h - 1, 14, 14);
                g2.setColor(BORDER_CARD);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, w - 1, h - 1, 14, 14);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // =========================================================================
    // CUSTOM COMPONENT 5: PillBadge (Rounded Status / Metric Pill)
    // =========================================================================

    public static class PillBadge extends JLabel {
        private Color pillBg;
        private Color pillBorder;
        private int radius = 16;

        public PillBadge(String text, Color pillBg, Color textColor, Color pillBorder) {
            super(text, SwingConstants.CENTER);
            this.pillBg = pillBg;
            this.pillBorder = pillBorder;
            setFont(FONT_BADGE);
            setForeground(textColor);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(5, 14, 5, 14));
        }

        public void setBadgeStyle(String text, Color pillBg, Color textColor, Color pillBorder) {
            setText(text);
            this.pillBg = pillBg;
            this.pillBorder = pillBorder;
            setForeground(textColor);
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(pillBg);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);

            if (pillBorder != null) {
                g2.setColor(pillBorder);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, radius, radius);
            }

            g2.dispose();
            super.paintComponent(g);
        }
    }

    // =========================================================================
    // REUSABLE FACTORY METHODS
    // =========================================================================

    public static RoundedPanel createCardPanel() {
        return new RoundedPanel(new BorderLayout(), 16, BG_CARD, BORDER_CARD, 24, 28);
    }

    public static RoundedPanel createCardPanel(LayoutManager layout, int topBottomPad, int leftRightPad) {
        return new RoundedPanel(layout, 16, BG_CARD, BORDER_CARD, topBottomPad, leftRightPad);
    }

    public static ModernButton createPrimaryButton(String text) {
        return new ModernButton(text, ACCENT_INDIGO, ACCENT_INDIGO_HOVER, Color.WHITE, null);
    }

    public static ModernButton createSecondaryButton(String text) {
        return new ModernButton(text, BG_CARD, BG_SUBTLE, TEXT_PRIMARY, BORDER_INPUT);
    }

    public static ModernButton createSuccessButton(String text) {
        return new ModernButton(text, SUCCESS_GREEN, SUCCESS_HOVER, Color.WHITE, null);
    }

    public static ModernButton createDangerButton(String text) {
        return new ModernButton(text, DANGER_SOFT_BG, new Color(254, 226, 226), DANGER_HOVER, DANGER_BORDER);
    }

    public static void styleTextField(JTextField field) {
        field.setFont(FONT_BODY);
        field.setForeground(TEXT_PRIMARY);
        field.setPreferredSize(new Dimension(240, 42));
        if (!(field instanceof ModernTextField) && !(field instanceof ModernPasswordField)) {
            field.setBackground(BG_CARD);
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER_INPUT, 1),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)
            ));
        }
    }

    public static void styleComboBox(JComboBox<?> combo) {
        combo.setFont(FONT_BODY);
        combo.setBackground(BG_CARD);
        combo.setForeground(TEXT_PRIMARY);
        combo.setPreferredSize(new Dimension(240, 42));
        combo.setBorder(BorderFactory.createLineBorder(BORDER_INPUT, 1));
    }

    public static void styleModernTable(JTable table, JScrollPane scrollPane) {
        table.setRowHeight(40);
        table.setFont(FONT_BODY);
        table.setForeground(TEXT_PRIMARY);
        table.setBackground(BG_CARD);
        table.setGridColor(BG_SUBTLE);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(ACCENT_INDIGO_SOFT);
        table.setSelectionForeground(ACCENT_INDIGO);
        table.setIntercellSpacing(new Dimension(0, 1));

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(header.getWidth(), 42));
        header.setFont(FONT_BADGE);
        header.setBackground(BG_SUBTLE);
        header.setForeground(TEXT_SECONDARY);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_CARD));

        DefaultTableCellRenderer cellRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object val, boolean isSel, boolean hasFoc, int r, int c) {
                Component comp = super.getTableCellRendererComponent(tbl, val, isSel, hasFoc, r, c);
                setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 14));
                if (!isSel) {
                    comp.setBackground(BG_CARD);
                    comp.setForeground(TEXT_PRIMARY);
                }
                return comp;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(cellRenderer);
        }

        if (scrollPane != null) {
            scrollPane.getViewport().setBackground(BG_CARD);
            scrollPane.setBorder(BorderFactory.createLineBorder(BORDER_CARD, 1));
        }
    }

    public static JPanel createHeaderBanner(String title, String subtitle) {
        return createHeaderBanner(title, subtitle, ACCENT_INDIGO);
    }

    public static JPanel createHeaderBanner(String title, String subtitle, Color accentColor) {
        JPanel banner = new JPanel(new BorderLayout(0, 4));
        banner.setBackground(BG_CARD);
        banner.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_CARD),
                BorderFactory.createEmptyBorder(20, 36, 20, 36)
        ));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(FONT_TITLE);
        titleLabel.setForeground(TEXT_PRIMARY);

        JLabel subLabel = new JLabel(subtitle);
        subLabel.setFont(FONT_SUBTITLE);
        subLabel.setForeground(TEXT_MUTED);

        banner.add(titleLabel, BorderLayout.NORTH);
        banner.add(subLabel, BorderLayout.SOUTH);
        return banner;
    }
}
