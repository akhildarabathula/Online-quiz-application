import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * ResultFrame.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Modern 2026 SaaS Candidate Response Sheet (GATE / JEE / HackerRank Style):
 *    - Hero Score Summary Card at the top displaying Final Score, Accuracy Metrics,
 *      Marking Scheme, and Proctoring Status.
 *    - Smooth-scrolling list of RoundedPanel Question Cards showing all 4 options,
 *      soft green/red selection highlights ('[Your Answer ✓]' / '[Your Answer ✗]'),
 *      and the bold green 'Correct Answer' footer bar at the bottom of each card.
 * 2. Method Overloading (Compile-Time Polymorphism):
 *    Calls 'QuizCalculator.calculateScore(...)' (2-arg vs 4-arg) based on whether
 *    negative marking is configured by the Professor.
 */
public class ResultFrame extends JFrame implements ActionListener {

    private User currentUser;
    private UITheme.ModernButton takeAnotherQuizButton;
    private UITheme.ModernButton logoutButton;
    private UITheme.ModernButton exitButton;

    /**
     * Constructor: Evaluates the exam, saves to results.txt, and renders the 1100x750 Response Sheet.
     */
    public ResultFrame(User currentUser, QuizConfig quizConfig, ArrayList<Question> questions,
                       int[] userAnswers, String submissionStatus) {
        this.currentUser = currentUser;

        int totalQuestions = questions.size();
        int correctCount = 0;
        int wrongCount = 0;
        int unansweredCount = 0;

        for (int i = 0; i < totalQuestions; i++) {
            int chosen = userAnswers[i];
            if (chosen == -1) {
                unansweredCount++;
            } else if (questions.get(i).isCorrect(chosen)) {
                correctCount++;
            } else {
                wrongCount++;
            }
        }

        // VIVA CONCEPT: Call Overloaded calculateScore() in QuizCalculator
        QuizCalculator calculator = new QuizCalculator();
        double marksPerQ = quizConfig.getMarksPerQuestion();
        double negativePenalty = quizConfig.getNegativeMarks();
        double finalScore;

        if (negativePenalty > 0) {
            finalScore = calculator.calculateScore(correctCount, wrongCount, marksPerQ, negativePenalty);
        } else {
            finalScore = calculator.calculateScore(correctCount, marksPerQ);
        }

        double maxPossibleScore = calculator.calculateMaxPossibleScore(totalQuestions, marksPerQ);

        // Save result to 'results.txt'
        FileManager.saveResult(
                currentUser.getUsername(),
                quizConfig.getSubject(),
                finalScore,
                totalQuestions,
                submissionStatus
        );

        // Configure 1100x750 Window
        setTitle("QuizFlow — Official Candidate Response Sheet (" + quizConfig.getSubject() + ")");
        setSize(1120, 760);
        setMinimumSize(new Dimension(1100, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG_CANVAS);

        // 1. Top Navigation Bar
        add(createTopReportBar(quizConfig.getSubject(), submissionStatus), BorderLayout.NORTH);

        // 2. Center Workspace (Hero Score Summary Card + Scrollable Question Response Cards)
        JPanel workspace = new JPanel(new BorderLayout(0, 20));
        workspace.setBackground(UITheme.BG_CANVAS);
        workspace.setBorder(BorderFactory.createEmptyBorder(24, 48, 20, 48));

        // 2A. Hero Score Summary Card
        workspace.add(createHeroSummaryCard(
                quizConfig, finalScore, maxPossibleScore,
                correctCount, wrongCount, unansweredCount, submissionStatus
        ), BorderLayout.NORTH);

        // 2B. Scrollable List of Rounded Question Cards
        JPanel cardsStack = new JPanel();
        cardsStack.setLayout(new BoxLayout(cardsStack, BoxLayout.Y_AXIS));
        cardsStack.setBackground(UITheme.BG_CANVAS);
        cardsStack.setBorder(BorderFactory.createEmptyBorder(4, 2, 16, 12));

        for (int i = 0; i < totalQuestions; i++) {
            UITheme.RoundedPanel qCard = createQuestionResponseCard(
                    i + 1,
                    questions.get(i),
                    userAnswers[i],
                    marksPerQ,
                    negativePenalty
            );
            cardsStack.add(qCard);
            cardsStack.add(Box.createRigidArea(new Dimension(0, 16)));
        }

        JScrollPane scrollPane = new JScrollPane(cardsStack);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(UITheme.BG_CANVAS);
        scrollPane.getVerticalScrollBar().setUnitIncrement(20);

        workspace.add(scrollPane, BorderLayout.CENTER);
        add(workspace, BorderLayout.CENTER);

        // 3. Bottom Action Bar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 14));
        bottomBar.setBackground(UITheme.BG_CARD);
        bottomBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER_CARD),
                BorderFactory.createEmptyBorder(4, 34, 4, 34)
        ));

        takeAnotherQuizButton = UITheme.createPrimaryButton("Attempt Another Assessment →");
        takeAnotherQuizButton.addActionListener(this);

        logoutButton = UITheme.createSecondaryButton("Sign Out");
        logoutButton.addActionListener(this);

        exitButton = UITheme.createDangerButton("Close Application");
        exitButton.addActionListener(this);

        bottomBar.add(logoutButton);
        bottomBar.add(exitButton);
        bottomBar.add(takeAnotherQuizButton);
        add(bottomBar, BorderLayout.SOUTH);
    }

    /**
     * Builds the top bar with Candidate info and Proctoring Submission Status Pill.
     */
    private JPanel createTopReportBar(String subject, String submissionStatus) {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(UITheme.BG_CARD);
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CARD),
                BorderFactory.createEmptyBorder(16, 48, 16, 48)
        ));

        JPanel leftBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftBox.setOpaque(false);

        JLabel reportTitle = new JLabel("Candidate Response Sheet & Scorecard");
        reportTitle.setFont(UITheme.FONT_SECTION);
        reportTitle.setForeground(UITheme.TEXT_PRIMARY);

        UITheme.PillBadge subjectPill = new UITheme.PillBadge(
                subject.toUpperCase(),
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );

        leftBox.add(reportTitle);
        leftBox.add(subjectPill);

        boolean isTabSwitch = QuizFrame.STATUS_TAB_SWITCH.equalsIgnoreCase(submissionStatus);
        UITheme.PillBadge statusPill = new UITheme.PillBadge(
                isTabSwitch ? "⚠ " + submissionStatus : "✓ " + submissionStatus,
                isTabSwitch ? UITheme.DANGER_SOFT_BG : UITheme.SUCCESS_SOFT_BG,
                isTabSwitch ? UITheme.DANGER_HOVER : UITheme.SUCCESS_HOVER,
                isTabSwitch ? UITheme.DANGER_BORDER : UITheme.SUCCESS_BORDER
        );

        bar.add(leftBox, BorderLayout.WEST);
        bar.add(statusPill, BorderLayout.EAST);
        return bar;
    }

    /**
     * Builds the Hero Score Summary Card at the top of the Response Sheet.
     */
    private UITheme.RoundedPanel createHeroSummaryCard(QuizConfig cfg, double finalScore, double maxScore,
                                                       int correct, int wrong, int unanswered, String status) {
        UITheme.RoundedPanel heroCard = new UITheme.RoundedPanel(
                new GridLayout(1, 5, 18, 0), 16, UITheme.BG_CARD, UITheme.BORDER_CARD, 20, 26
        );

        heroCard.add(createHeroStatBox(
                "FINAL SCORE",
                finalScore + " / " + maxScore,
                "Candidate: " + currentUser.getUsername(),
                UITheme.ACCENT_INDIGO
        ));

        heroCard.add(createHeroStatBox(
                "CORRECT ANSWERS",
                String.valueOf(correct),
                "+" + (correct * cfg.getMarksPerQuestion()) + " marks earned",
                UITheme.SUCCESS_GREEN
        ));

        heroCard.add(createHeroStatBox(
                "INCORRECT ANSWERS",
                String.valueOf(wrong),
                "-" + (wrong * cfg.getNegativeMarks()) + " penalty deducted",
                UITheme.DANGER_RED
        ));

        heroCard.add(createHeroStatBox(
                "UNANSWERED",
                String.valueOf(unanswered),
                "0.0 marks (skipped)",
                UITheme.TEXT_MUTED
        ));

        heroCard.add(createHeroStatBox(
                "MARKING SCHEME",
                "+" + cfg.getMarksPerQuestion() + " / -" + cfg.getNegativeMarks(),
                cfg.getTimePerQuestionSeconds() + "s per question",
                UITheme.TEXT_PRIMARY
        ));

        return heroCard;
    }

    private JPanel createHeroStatBox(String label, String bigValue, String subCaption, Color accent) {
        JPanel box = new JPanel(new BorderLayout(0, 4));
        box.setOpaque(false);

        JLabel topLbl = new JLabel(label);
        topLbl.setFont(UITheme.FONT_BADGE);
        topLbl.setForeground(UITheme.TEXT_MUTED);

        JLabel valLbl = new JLabel(bigValue);
        valLbl.setFont(UITheme.FONT_TITLE);
        valLbl.setForeground(accent);

        JLabel subLbl = new JLabel(subCaption);
        subLbl.setFont(UITheme.FONT_SMALL);
        subLbl.setForeground(UITheme.TEXT_MUTED);

        box.add(topLbl, BorderLayout.NORTH);
        box.add(valLbl, BorderLayout.CENTER);
        box.add(subLbl, BorderLayout.SOUTH);
        return box;
    }

    /**
     * Builds a single rounded Question Card for the scrollable Candidate Response Sheet.
     */
    private UITheme.RoundedPanel createQuestionResponseCard(int qNumber, Question q, int userChoice,
                                                            double marksPerQ, double negMarks) {
        UITheme.RoundedPanel card = new UITheme.RoundedPanel(
                new BorderLayout(0, 14), 16, UITheme.BG_CARD, UITheme.BORDER_CARD, 22, 26
        );

        int correctIndex = q.getCorrectOptionIndex();
        boolean isUnanswered = (userChoice == -1);
        boolean isCorrect = (userChoice == correctIndex);

        // 1. Header Row: Q# + Question Statement on Left, Status Pill Badge on Right
        JPanel headerRow = new JPanel(new BorderLayout(16, 0));
        headerRow.setOpaque(false);

        JLabel qLabel = new JLabel(
                "<html><body style='width: 680px; line-height: 1.4; font-family: Segoe UI;'>"
                        + "<b>Q" + qNumber + ".</b> " + q.getQuestionText()
                        + "</body></html>"
        );
        qLabel.setFont(UITheme.FONT_HEADING);
        qLabel.setForeground(UITheme.TEXT_PRIMARY);

        UITheme.PillBadge outcomeBadge;
        if (isUnanswered) {
            outcomeBadge = new UITheme.PillBadge(
                    "0.0 Marks • Unanswered",
                    UITheme.BG_SUBTLE,
                    UITheme.TEXT_MUTED,
                    UITheme.BORDER_CARD
            );
        } else if (isCorrect) {
            outcomeBadge = new UITheme.PillBadge(
                    "+" + marksPerQ + " Marks • Correct",
                    UITheme.SUCCESS_SOFT_BG,
                    UITheme.SUCCESS_HOVER,
                    UITheme.SUCCESS_BORDER
            );
        } else {
            outcomeBadge = new UITheme.PillBadge(
                    "-" + negMarks + " Marks • Incorrect",
                    UITheme.DANGER_SOFT_BG,
                    UITheme.DANGER_HOVER,
                    UITheme.DANGER_BORDER
            );
        }

        JPanel badgeWrapper = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        badgeWrapper.setOpaque(false);
        badgeWrapper.add(outcomeBadge);

        headerRow.add(qLabel, BorderLayout.CENTER);
        headerRow.add(badgeWrapper, BorderLayout.EAST);
        card.add(headerRow, BorderLayout.NORTH);

        // 2. Options Stack: All 4 Options (A, B, C, D) in Rounded Rows
        JPanel optionsGrid = new JPanel(new GridLayout(4, 1, 0, 8));
        optionsGrid.setOpaque(false);

        String[] opts = q.getOptions();
        char[] letters = {'A', 'B', 'C', 'D'};

        for (int i = 0; i < 4; i++) {
            Color rowFill;
            Color rowBorder;
            String tagText = "";
            Color tagColor = UITheme.TEXT_MUTED;

            if (i == userChoice && isCorrect) {
                rowFill = UITheme.SUCCESS_SOFT_BG;
                rowBorder = UITheme.SUCCESS_BORDER;
                tagText = "[Your Answer ✓]";
                tagColor = UITheme.SUCCESS_HOVER;
            } else if (i == userChoice && !isCorrect) {
                rowFill = UITheme.DANGER_SOFT_BG;
                rowBorder = UITheme.DANGER_BORDER;
                tagText = "[Your Answer ✗]";
                tagColor = UITheme.DANGER_HOVER;
            } else {
                rowFill = UITheme.BG_CANVAS;
                rowBorder = UITheme.BORDER_CARD;
            }

            UITheme.RoundedPanel optRow = new UITheme.RoundedPanel(
                    new BorderLayout(12, 0), 10, rowFill, rowBorder, 10, 16
            );

            JLabel optText = new JLabel(letters[i] + ".   " + opts[i]);
            optText.setFont((i == userChoice) ? UITheme.FONT_BOLD : UITheme.FONT_BODY);
            optText.setForeground(UITheme.TEXT_PRIMARY);
            optRow.add(optText, BorderLayout.WEST);

            if (!tagText.isEmpty()) {
                JLabel tagLabel = new JLabel(tagText);
                tagLabel.setFont(UITheme.FONT_BOLD);
                tagLabel.setForeground(tagColor);
                optRow.add(tagLabel, BorderLayout.EAST);
            }

            optionsGrid.add(optRow);
        }

        card.add(optionsGrid, BorderLayout.CENTER);

        // 3. Footer Bar: Official Correct Answer in Bold Green
        UITheme.RoundedPanel footerBar = new UITheme.RoundedPanel(
                new BorderLayout(), 10, UITheme.SUCCESS_SOFT_BG, UITheme.SUCCESS_BORDER, 10, 16
        );

        JLabel correctAnsLabel = new JLabel(
                "✓  Correct Answer: Option " + letters[correctIndex] + " — " + opts[correctIndex]
        );
        correctAnsLabel.setFont(UITheme.FONT_BOLD);
        correctAnsLabel.setForeground(UITheme.SUCCESS_HOVER);

        footerBar.add(correctAnsLabel, BorderLayout.WEST);
        card.add(footerBar, BorderLayout.SOUTH);

        return card;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == takeAnotherQuizButton) {
            QuizSelectionFrame selectionFrame = new QuizSelectionFrame(currentUser);
            selectionFrame.setVisible(true);
            this.dispose();
        } else if (e.getSource() == logoutButton) {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            this.dispose();
        } else if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }
}
