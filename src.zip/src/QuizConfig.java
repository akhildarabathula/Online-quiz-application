import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * QuizConfig.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Encapsulation & Model Class:
 *    Represents the Professor's configuration for a quiz subject, including:
 *    - numQuestionsToPick, timePerQuestionSeconds, marksPerQuestion, negativeMarks
 *    - examActive (boolean): Whether the Professor has enabled/opened the exam
 *    - examTimeWindow (String): Scheduled start and end time (e.g., "09:00|17:00"
 *      or "2026-11-14T10:00|2026-11-14T11:00")
 * 2. Constructor Overloading:
 *    Provides 7-parameter, 5-parameter, and 4-parameter constructors so both the
 *    new Web Server and legacy Swing frames work seamlessly.
 * 3. Java 8+ Date/Time API (java.time.LocalTime & LocalDateTime):
 *    Evaluates whether the current server clock falls inside the scheduled exam window.
 */
public class QuizConfig {

    // Private fields (Encapsulation)
    private String subject;
    private int numQuestionsToPick;
    private int timePerQuestionSeconds;
    private double marksPerQuestion;
    private double negativeMarks;
    private boolean examActive;
    private String examTimeWindow; // Format: "HH:mm|HH:mm" or "yyyy-MM-ddTHH:mm|yyyy-MM-ddTHH:mm"

    /**
     * Constructor 1 (Full 7-Parameter Constructor):
     * Initializes all quiz rules including Exam Active status and Exam Timing Window.
     */
    public QuizConfig(String subject, int numQuestionsToPick, int timePerQuestionSeconds,
                      double marksPerQuestion, double negativeMarks,
                      boolean examActive, String examTimeWindow) {
        this.subject = subject;
        this.numQuestionsToPick = numQuestionsToPick;
        this.timePerQuestionSeconds = timePerQuestionSeconds;
        this.marksPerQuestion = marksPerQuestion;
        this.negativeMarks = negativeMarks;
        this.examActive = examActive;
        this.examTimeWindow = (examTimeWindow == null || examTimeWindow.trim().isEmpty())
                ? "00:00|23:59"
                : examTimeWindow.trim();
    }

    /**
     * Constructor 2 (Overloaded 5-Parameter Constructor):
     * Defaults examActive to true and examTimeWindow to "00:00|23:59" (all day).
     */
    public QuizConfig(String subject, int numQuestionsToPick, int timePerQuestionSeconds,
                      double marksPerQuestion, double negativeMarks) {
        this(subject, numQuestionsToPick, timePerQuestionSeconds, marksPerQuestion, negativeMarks, true, "00:00|23:59");
    }

    /**
     * Constructor 3 (Overloaded 4-Parameter Constructor):
     * Defaults marksPerQuestion to 4.0, examActive to true, and examTimeWindow to "00:00|23:59".
     */
    public QuizConfig(String subject, int numQuestionsToPick, int timePerQuestionSeconds, double negativeMarks) {
        this(subject, numQuestionsToPick, timePerQuestionSeconds, 4.0, negativeMarks, true, "00:00|23:59");
    }

    // ==================== GETTERS & SETTERS (Encapsulation) ====================

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getNumQuestionsToPick() {
        return numQuestionsToPick;
    }

    public void setNumQuestionsToPick(int numQuestionsToPick) {
        this.numQuestionsToPick = numQuestionsToPick;
    }

    public int getTimePerQuestionSeconds() {
        return timePerQuestionSeconds;
    }

    public void setTimePerQuestionSeconds(int timePerQuestionSeconds) {
        this.timePerQuestionSeconds = timePerQuestionSeconds;
    }

    public double getMarksPerQuestion() {
        return marksPerQuestion;
    }

    public void setMarksPerQuestion(double marksPerQuestion) {
        this.marksPerQuestion = marksPerQuestion;
    }

    public double getNegativeMarks() {
        return negativeMarks;
    }

    public void setNegativeMarks(double negativeMarks) {
        this.negativeMarks = negativeMarks;
    }

    public boolean isExamActive() {
        return examActive;
    }

    public void setExamActive(boolean examActive) {
        this.examActive = examActive;
    }

    public String getExamTimeWindow() {
        return examTimeWindow;
    }

    public void setExamTimeWindow(String examTimeWindow) {
        this.examTimeWindow = (examTimeWindow == null || examTimeWindow.trim().isEmpty())
                ? "00:00|23:59"
                : examTimeWindow.trim();
    }

    /**
     * Extracts the start time string (e.g., "09:00") from examTimeWindow.
     */
    public String getStartTimePart() {
        if (examTimeWindow != null && examTimeWindow.contains("|")) {
            return examTimeWindow.split("\\|")[0].trim();
        }
        return "00:00";
    }

    /**
     * Extracts the end time string (e.g., "17:00") from examTimeWindow.
     */
    public String getEndTimePart() {
        if (examTimeWindow != null && examTimeWindow.contains("|")) {
            String[] parts = examTimeWindow.split("\\|");
            if (parts.length >= 2) {
                return parts[1].trim();
            }
        }
        return "23:59";
    }

    /**
     * Formats the timing window into a friendly 12-hour string (e.g., "10:00 AM - 11:00 AM").
     */
    public String getFormattedTimeWindow() {
        if (examTimeWindow == null || examTimeWindow.trim().isEmpty()) {
            return "All Day (Open)";
        }
        if (!examTimeWindow.contains("|")) {
            return examTimeWindow;
        }

        String startRaw = getStartTimePart();
        String endRaw = getEndTimePart();
        if ("00:00".equals(startRaw) && "23:59".equals(endRaw)) {
            return "12:00 AM - 11:59 PM (All Day)";
        }

        try {
            if (startRaw.contains("T")) {
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMM hh:mm a", Locale.ENGLISH);
                LocalDateTime s = LocalDateTime.parse(startRaw);
                LocalDateTime e = LocalDateTime.parse(endRaw);
                return s.format(dtf) + " - " + e.format(dtf);
            } else {
                DateTimeFormatter tf = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);
                LocalTime s = LocalTime.parse(startRaw);
                LocalTime e = LocalTime.parse(endRaw);
                return s.format(tf) + " - " + e.format(tf);
            }
        } catch (Exception ex) {
            return startRaw + " - " + endRaw;
        }
    }

    /**
     * VIVA CONCEPT: Server-Side Exam Window Validation
     * Checks if:
     * 1) The Professor has enabled the exam (examActive == true), AND
     * 2) The current server clock falls within [startTime, endTime].
     */
    public boolean isAvailableRightNow() {
        if (!examActive) {
            return false; // Explicitly closed/paused by the Professor
        }
        if (examTimeWindow == null || examTimeWindow.trim().isEmpty() || !examTimeWindow.contains("|")) {
            return true;
        }

        String startRaw = getStartTimePart();
        String endRaw = getEndTimePart();
        if ("00:00".equals(startRaw) && "23:59".equals(endRaw)) {
            return true;
        }

        try {
            if (startRaw.contains("T") && endRaw.contains("T")) {
                LocalDateTime now = LocalDateTime.now();
                LocalDateTime start = LocalDateTime.parse(startRaw);
                LocalDateTime end = LocalDateTime.parse(endRaw);
                return !now.isBefore(start) && !now.isAfter(end);
            } else {
                LocalTime now = LocalTime.now();
                LocalTime start = LocalTime.parse(startRaw);
                LocalTime end = LocalTime.parse(endRaw);

                if (!end.isBefore(start)) {
                    // Normal daytime window (e.g., 10:00 to 11:00)
                    return !now.isBefore(start) && !now.isAfter(end);
                } else {
                    // Overnight window (e.g., 22:00 to 02:00)
                    return !now.isBefore(start) || !now.isAfter(end);
                }
            }
        } catch (Exception e) {
            // If custom descriptive string like "10:00 AM - 11:00 AM" is used, rely on examActive
            return examActive;
        }
    }

    /**
     * Converts this configuration object into a 7-column CSV line for 'quiz_config.txt'.
     * Format: subject,numQuestionsToPick,timePerQuestionSeconds,marksPerQuestion,negativeMarks,examActive,examTimeWindow
     */
    public String toCsvString() {
        return subject + ","
                + numQuestionsToPick + ","
                + timePerQuestionSeconds + ","
                + marksPerQuestion + ","
                + negativeMarks + ","
                + examActive + ","
                + examTimeWindow;
    }
}
