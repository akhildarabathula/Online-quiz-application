/**
 * Person.java
 * 
 * VIVA CONCEPT: Encapsulation & Base Class (Parent Class for Inheritance)
 * - Encapsulation: Binding data (variables) and methods together into a single unit,
 *   and restricting direct access by making fields 'private'.
 * - Getters and Setters: Public methods used to safely read and modify private variables.
 */
public class Person {
    
    // Private field (Encapsulation: cannot be accessed directly outside this class)
    private String username;

    /**
     * VIVA CONCEPT: Parameterized Constructor
     * A special method called automatically when an object is created to initialize variables.
     * 
     * @param username The name/username of the person
     */
    public Person(String username) {
        this.username = username; // 'this' refers to the current object's instance variable
    }

    /**
     * Getter method to read the private username variable.
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Setter method to update the private username variable.
     * @param username New username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }
}
