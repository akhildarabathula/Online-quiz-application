import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * FileManager.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. File Handling: Reading, appending, and updating text files (.txt) using
 *    FileReader, BufferedReader, FileWriter, and BufferedWriter.
 * 2. Exception Handling: Using 'try-catch' blocks to handle IOException and
 *    NumberFormatException gracefully without crashing the program.
 * 3. Java Collections Framework:
 *    - ArrayList<Question>, ArrayList<QuizConfig>, ArrayList<String[]> for dynamic storage.
 *    - Collections.shuffle() to randomize the MCQ question bank for each student attempt.
 * 4. Exam Timing Schedule & Bulk Student Unlocking:
 *    - Supports 7-column 'quiz_config.txt' with 'examActive' and 'examTimeWindow'.
 *    - Provides 'unlockExamForStudent', 'unlockAllStudentsForSubject', and
 *      'unlockAllStudentsGlobally' for atomic single-file rewrites on 'results.txt'.
 */
public class FileManager {

    private static final String USERS_FILE = "users.txt";
    private static final String QUIZ_CONFIG_FILE = "quiz_config.txt";
    private static final String QUESTIONS_FILE = "questions.txt";
    private static final String RESULTS_FILE = "results.txt";

    /**
     * Helper method to locate data files whether the program is run from
     * the project root folder ("d:/java project") or inside the "src" folder.
     */
    public static File resolveFile(String fileName) {
        File fileInCurrentDir = new File(fileName);
        if (fileInCurrentDir.exists()) {
            return fileInCurrentDir;
        }
        File fileInParentDir = new File("..", fileName);
        if (fileInParentDir.exists()) {
            return fileInParentDir;
        }
        return fileInCurrentDir;
    }

    /**
     * Ensures that all 4 sample data files exist before the application starts.
     */
    public static void initializeDataFiles() {
        try {
            // 1. Initialize users.txt (username,password,role)
            File usersFile = resolveFile(USERS_FILE);
            if (!usersFile.exists()) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(usersFile))) {
                    writer.write("admin,admin123,ADMIN\n");
                    writer.write("student1,pass123,STUDENT\n");
                    writer.write("rahul,java2026,STUDENT\n");
                }
            }

            // 2. Initialize quiz_config.txt
            // Format: subject,numQuestionsToPick,timePerQuestionSeconds,marksPerQuestion,negativeMarks,examActive,examTimeWindow
            File configFile = resolveFile(QUIZ_CONFIG_FILE);
            if (!configFile.exists()) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(configFile))) {
                    writer.write("Java Programming,5,15,4.0,1.0,true,00:00|23:59\n");
                    writer.write("Quantitative Aptitude,5,20,4.0,0.0,true,00:00|23:59\n");
                }
            }

            // 3. Initialize questions.txt
            File questionsFile = resolveFile(QUESTIONS_FILE);
            if (!questionsFile.exists()) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(questionsFile))) {
                    writer.write("Java Programming,Which keyword is used to inherit a class in Java?,implements,extends,inherits,super,1\n");
                    writer.write("Java Programming,Which of the following is NOT one of the 4 pillars of OOP?,Encapsulation,Polymorphism,Compilation,Inheritance,2\n");
                    writer.write("Java Programming,What is the default value of an uninitialized int variable in a class?,0,null,1,Garbage value,0\n");
                    writer.write("Java Programming,Which collection class allows dynamic resizing of an array in Java?,Array,ArrayList,FixedList,HashSet,1\n");
                    writer.write("Java Programming,Which block is always executed in exception handling regardless of whether an exception occurs?,try,catch,throw,finally,3\n");
                    writer.write("Java Programming,Which method of Collections class is used to randomly reorder elements in an ArrayList?,Collections.random(),Collections.shuffle(),Collections.mix(),Collections.sort(),1\n");
                    writer.write("Java Programming,Which Swing class is used to fire periodic action events for a countdown timer?,java.util.Timer,javax.swing.Timer,javax.swing.Clock,java.awt.Timer,1\n");
                    writer.write("Quantitative Aptitude,If the cost price of an item is Rs. 200 and it is sold at a 15% profit what is the selling price?,Rs. 215,Rs. 220,Rs. 230,Rs. 240,2\n");
                    writer.write("Quantitative Aptitude,A train running at 72 km/hr crosses a pole in 15 seconds. What is the length of the train?,200 meters,300 meters,400 meters,1080 meters,1\n");
                    writer.write("Quantitative Aptitude,What is the average of the first five multiples of 4?,8,10,12,16,2\n");
                    writer.write("Quantitative Aptitude,If 12 workers can build a wall in 10 days how many days will 15 workers take to build the same wall?,6 days,8 days,9 days,12 days,1\n");
                    writer.write("Quantitative Aptitude,Find the next number in the series: 3 6 11 18 27 ?,36,38,40,42,1\n");
                    writer.write("Quantitative Aptitude,A sum of Rs. 800 amounts to Rs. 920 in 3 years at simple interest. What is the interest rate per annum?,4%,5%,6%,8%,1\n");
                    writer.write("Quantitative Aptitude,If the ratio of boys to girls in a class of 60 students is 3:2 how many boys are there?,24,30,36,40,2\n");
                }
            }

            // 4. Initialize results.txt
            File resultsFile = resolveFile(RESULTS_FILE);
            if (!resultsFile.exists()) {
                resultsFile.createNewFile();
            }
        } catch (IOException e) {
            System.out.println("Error initializing files: " + e.getMessage());
        }
    }

    // =========================================================================
    // 1. USER LOGIN & REGISTRATION METHODS (users.txt)
    // =========================================================================

    public static synchronized User validateLogin(String username, String password) {
        File file = resolveFile(USERS_FILE);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length >= 2) {
                    String storedUser = parts[0].trim();
                    String storedPass = parts[1].trim();
                    String storedRole = (parts.length >= 3) ? parts[2].trim() : User.ROLE_STUDENT;

                    if (storedUser.equals(username) && storedPass.equals(password)) {
                        return new User(storedUser, storedPass, storedRole);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading users file: " + e.getMessage());
        }
        return null;
    }

    public static synchronized boolean registerUser(User newUser) {
        File file = resolveFile(USERS_FILE);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length >= 1 && parts[0].trim().equalsIgnoreCase(newUser.getUsername())) {
                    return false;
                }
            }
        } catch (IOException e) {
            // Proceed if file does not exist yet
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(newUser.getUsername() + "," + newUser.getPassword() + "," + newUser.getRole());
            writer.newLine();
            return true;
        } catch (IOException e) {
            System.out.println("Error registering user: " + e.getMessage());
            return false;
        }
    }

    // =========================================================================
    // 2. QUIZ CONFIGURATION & EXAM TIMING METHODS (quiz_config.txt)
    // =========================================================================

    /**
     * Loads all subject configurations from 'quiz_config.txt'.
     * 7-column format:
     * subject,numQuestionsToPick,timePerQuestionSeconds,marksPerQuestion,negativeMarks,examActive,examTimeWindow
     * (Also supports legacy 5-column and 4-column lines smoothly)
     */
    public static synchronized ArrayList<QuizConfig> loadAllQuizConfigs() {
        ArrayList<QuizConfig> configs = new ArrayList<>();
        File file = resolveFile(QUIZ_CONFIG_FILE);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.trim().split(",");
                if (parts.length >= 7) {
                    String subject = parts[0].trim();
                    int numQuestions = Integer.parseInt(parts[1].trim());
                    int timeSeconds = Integer.parseInt(parts[2].trim());
                    double marksPerQ = Double.parseDouble(parts[3].trim());
                    double negMarks = Double.parseDouble(parts[4].trim());
                    boolean examActive = Boolean.parseBoolean(parts[5].trim());
                    String timeWindow = parts[6].trim();

                    configs.add(new QuizConfig(subject, numQuestions, timeSeconds, marksPerQ, negMarks, examActive, timeWindow));
                } else if (parts.length >= 5) {
                    String subject = parts[0].trim();
                    int numQuestions = Integer.parseInt(parts[1].trim());
                    int timeSeconds = Integer.parseInt(parts[2].trim());
                    double marksPerQ = Double.parseDouble(parts[3].trim());
                    double negMarks = Double.parseDouble(parts[4].trim());

                    configs.add(new QuizConfig(subject, numQuestions, timeSeconds, marksPerQ, negMarks, true, "00:00|23:59"));
                } else if (parts.length == 4) {
                    String subject = parts[0].trim();
                    int numQuestions = Integer.parseInt(parts[1].trim());
                    int timeSeconds = Integer.parseInt(parts[2].trim());
                    double negMarks = Double.parseDouble(parts[3].trim());

                    configs.add(new QuizConfig(subject, numQuestions, timeSeconds, 4.0, negMarks, true, "00:00|23:59"));
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading quiz configs: " + e.getMessage());
        }
        return configs;
    }

    public static synchronized QuizConfig getQuizConfigBySubject(String subject) {
        ArrayList<QuizConfig> configs = loadAllQuizConfigs();
        for (QuizConfig cfg : configs) {
            if (cfg.getSubject().equalsIgnoreCase(subject)) {
                return cfg;
            }
        }
        return new QuizConfig(subject, 5, 15, 4.0, 0.0, true, "00:00|23:59");
    }

    /**
     * Creates a new subject configuration or updates an existing subject's rules in 'quiz_config.txt'.
     */
    public static synchronized boolean saveOrUpdateQuizConfig(QuizConfig newConfig) {
        ArrayList<QuizConfig> configs = loadAllQuizConfigs();
        boolean updatedExisting = false;

        for (int i = 0; i < configs.size(); i++) {
            if (configs.get(i).getSubject().equalsIgnoreCase(newConfig.getSubject())) {
                configs.set(i, newConfig);
                updatedExisting = true;
                break;
            }
        }

        if (!updatedExisting) {
            configs.add(newConfig);
        }

        File file = resolveFile(QUIZ_CONFIG_FILE);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
            for (QuizConfig cfg : configs) {
                writer.write(cfg.toCsvString());
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error saving quiz config: " + e.getMessage());
            return false;
        }
    }

    /**
     * Allows the Professor/Admin to immediately toggle an exam OPEN or CLOSED,
     * and optionally update its scheduled exam timing window during a live exam.
     * 
     * @param subject        Subject name to toggle
     * @param examActive     true to open for students, false to close/pause
     * @param examTimeWindow Optional new timing window (e.g., "10:00|11:00"), or null to keep existing
     * @return true if updated successfully
     */
    public static synchronized boolean updateExamScheduleAndStatus(String subject, boolean examActive, String examTimeWindow) {
        QuizConfig cfg = getQuizConfigBySubject(subject);
        cfg.setExamActive(examActive);
        if (examTimeWindow != null && !examTimeWindow.trim().isEmpty()) {
            cfg.setExamTimeWindow(examTimeWindow.trim());
        }
        return saveOrUpdateQuizConfig(cfg);
    }

    // =========================================================================
    // 3. QUESTION BANK & RANDOMIZATION METHODS (questions.txt)
    // =========================================================================

    public static synchronized boolean addQuestionToFile(Question question) {
        File file = resolveFile(QUESTIONS_FILE);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(question.toCsvString());
            writer.newLine();
            return true;
        } catch (IOException e) {
            System.out.println("Error adding question: " + e.getMessage());
            return false;
        }
    }

    public static synchronized ArrayList<Question> loadQuestionsBySubject(String selectedSubject) {
        ArrayList<Question> questionList = new ArrayList<>();
        File file = resolveFile(QUESTIONS_FILE);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(",");
                if (parts.length == 7) {
                    String subject = parts[0].trim();

                    if (subject.equalsIgnoreCase(selectedSubject)) {
                        String questionText = parts[1].trim();
                        String[] options = new String[] {
                            parts[2].trim(),
                            parts[3].trim(),
                            parts[4].trim(),
                            parts[5].trim()
                        };
                        int correctIndex = Integer.parseInt(parts[6].trim());

                        Question q = new Question(subject, questionText, options, correctIndex);
                        questionList.add(q);
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Error loading questions: " + e.getMessage());
        }

        return questionList;
    }

    public static synchronized ArrayList<Question> getQuestionsForQuiz(String subject, int limit) {
        ArrayList<Question> allSubjectQuestions = loadQuestionsBySubject(subject);
        Collections.shuffle(allSubjectQuestions);

        if (limit > 0 && allSubjectQuestions.size() > limit) {
            List<Question> subList = allSubjectQuestions.subList(0, limit);
            return new ArrayList<>(subList);
        }

        return allSubjectQuestions;
    }

    // =========================================================================
    // 4. STUDENT RESULTS, INDIVIDUAL UNLOCK & BULK UNLOCK ALL (results.txt)
    //    Format: username,subject,score,maxScore,status,locked
    // =========================================================================

    public static synchronized void saveResult(String username, String subject, double score,
                                               double maxScore, String status, boolean locked) {
        File file = resolveFile(RESULTS_FILE);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(username + "," + subject + "," + score + "," + maxScore + "," + status + "," + locked);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving quiz result: " + e.getMessage());
        }
    }

    public static synchronized void saveResult(String username, String subject, double score,
                                               int totalQuestions, String status) {
        QuizConfig cfg = getQuizConfigBySubject(subject);
        double maxScore = totalQuestions * cfg.getMarksPerQuestion();
        saveResult(username, subject, score, maxScore, status, true);
    }

    public static synchronized void saveResult(String username, String subject, double score, int totalQuestions) {
        saveResult(username, subject, score, totalQuestions, "COMPLETED");
    }

    public static synchronized boolean isExamLocked(String username, String subject) {
        ArrayList<String[]> allRows = loadAllResults();
        boolean locked = false;

        for (String[] row : allRows) {
            if (row[0].equalsIgnoreCase(username) && row[1].equalsIgnoreCase(subject)) {
                locked = Boolean.parseBoolean(row[5]);
            }
        }
        return locked;
    }

    public static synchronized String[] getLatestResultForStudent(String username, String subject) {
        ArrayList<String[]> allRows = loadAllResults();
        String[] latest = null;
        for (String[] row : allRows) {
            if (row[0].equalsIgnoreCase(username) && row[1].equalsIgnoreCase(subject)) {
                latest = row;
            }
        }
        return latest;
    }

    /**
     * Unlocks a single student's locked attempt for a specific subject.
     */
    public static synchronized boolean unlockExamForStudent(String username, String subject) {
        ArrayList<String[]> allRows = loadAllResults();
        boolean foundMatch = false;

        for (String[] row : allRows) {
            if (row[0].equalsIgnoreCase(username) && row[1].equalsIgnoreCase(subject)) {
                row[5] = "false";
                foundMatch = true;
            }
        }

        if (!foundMatch) {
            return false;
        }

        return writeAllResultsRows(allRows);
    }

    /**
     * VIVA CONCEPT: Bulk Unlock for a Specific Subject
     * Scans 'results.txt' and sets 'locked = false' for EVERY student who is locked
     * on the specified subject in a single atomic file rewrite.
     * 
     * @param subject Subject name to unlock for all students (or "ALL" for global unlock)
     * @return Number of locked student attempts that were unlocked
     */
    public static synchronized int unlockAllStudentsForSubject(String subject) {
        if (subject == null || subject.trim().isEmpty() || "ALL".equalsIgnoreCase(subject.trim())) {
            return unlockAllStudentsGlobally();
        }

        ArrayList<String[]> allRows = loadAllResults();
        int unlockedCount = 0;

        for (String[] row : allRows) {
            if (row[1].equalsIgnoreCase(subject.trim()) && Boolean.parseBoolean(row[5])) {
                row[5] = "false";
                unlockedCount++;
            }
        }

        if (unlockedCount > 0) {
            writeAllResultsRows(allRows);
        }
        return unlockedCount;
    }

    /**
     * VIVA CONCEPT: Global Bulk Unlock Across All Subjects
     * Scans 'results.txt' and sets 'locked = false' across ALL student attempts
     * for ALL subjects at once in a single atomic file rewrite.
     * 
     * @return Total number of locked student attempts that were unlocked
     */
    public static synchronized int unlockAllStudentsGlobally() {
        ArrayList<String[]> allRows = loadAllResults();
        int unlockedCount = 0;

        for (String[] row : allRows) {
            if (Boolean.parseBoolean(row[5])) {
                row[5] = "false";
                unlockedCount++;
            }
        }

        if (unlockedCount > 0) {
            writeAllResultsRows(allRows);
        }
        return unlockedCount;
    }

    /**
     * Internal helper that rewrites 'results.txt' atomically with updated rows.
     */
    private static synchronized boolean writeAllResultsRows(ArrayList<String[]> allRows) {
        File file = resolveFile(RESULTS_FILE);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
            for (String[] row : allRows) {
                writer.write(row[0] + "," + row[1] + "," + row[2] + "," + row[3] + "," + row[4] + "," + row[5]);
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error writing results file: " + e.getMessage());
            return false;
        }
    }

    public static synchronized ArrayList<String[]> loadAllResults() {
        ArrayList<String[]> resultsList = new ArrayList<>();
        File file = resolveFile(RESULTS_FILE);

        if (!file.exists()) {
            return resultsList;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.trim().split(",");
                if (parts.length >= 4) {
                    String username = parts[0].trim();
                    String subject = parts[1].trim();
                    String score = parts[2].trim();
                    String maxScore = parts[3].trim();
                    String status = (parts.length >= 5) ? parts[4].trim() : "COMPLETED";
                    String locked = (parts.length >= 6) ? parts[5].trim() : "true";

                    resultsList.add(new String[] { username, subject, score, maxScore, status, locked });
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading results file: " + e.getMessage());
        }

        return resultsList;
    }
}
