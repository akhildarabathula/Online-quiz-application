import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.Timer;

/**
 * QuizFrame.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Distraction-Free 2026 SaaS Exam Interface (inspired by HackerRank / Linear):
 *    - Top progress bar ('Question 2 of 5') and pill-shaped countdown timer badge
 *      that turns crimson red under 5 seconds.
 *    - Large readable question card with 1.4 line-height HTML typography.
 *    - 4 clickable custom 'UITheme.OptionCard' panels (A, B, C, D) replacing old
 *      default JRadioButton circles.
 * 2. Per-Question Countdown Timer (javax.swing.Timer):
 *    Automatically advances to the next question (or submits on the last question) at 0s.
 * 3. Anti-Cheating Proctoring (WindowFocusListener):
 *    Detects window/tab switches ('windowLostFocus') and immediately auto-submits the exam.
 */
public class QuizFrame extends JFrame implements ActionListener, WindowFocusListener {

    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_TAB_SWITCH = "AUTO-SUBMITTED (TAB SWITCH)";

    private User currentUser;
    private QuizConfig quizConfig;
    private ArrayList<Question> questions;

    private int currentQuestionIndex = 0;
    private int[] userAnswers; // Stores 0, 1, 2, 3, or -1 for unanswered

    private Timer questionTimer;
    private int remainingSeconds;
    private boolean isQuizFinished = false;

    // UI Components
    private JLabel progressCounterLabel;
    private UITheme.PillBadge timerPillBadge;
    private JProgressBar questionProgressBar;
    private JLabel questionTextLabel;
    private UITheme.OptionCard[] optionCards;
    private UITheme.ModernButton prevButton;
    private UITheme.ModernButton clearSelectionButton;
    private UITheme.ModernButton nextButton;
    private UITheme.ModernButton submitButton;

    /**
     * Constructor: Sets up the 1100x750 HackerRank-inspired proctored exam workspace.
     */
    public QuizFrame(User currentUser, QuizConfig quizConfig, ArrayList<Question> questions) {
        this.currentUser = currentUser;
        this.quizConfig = quizConfig;
        this.questions = questions;

        this.userAnswers = new int[questions.size()];
        Arrays.fill(this.userAnswers, -1);

        setTitle("QuizFlow Proctored Assessment — " + quizConfig.getSubject());
        setSize(1120, 760);
        setMinimumSize(new Dimension(1100, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG_CANVAS);

        // Register Anti-Cheat Focus Listener
        addWindowFocusListener(this);

        // 1. Top Bar: Subject Info, Question Progress Counter, Pill Timer Badge, and Progress Bar
        add(createTopExamHeader(), BorderLayout.NORTH);

        // 2. Center Exam Workspace with generous 36px-48px padding
        JPanel centerWorkspace = new JPanel(new BorderLayout(0, 22));
        centerWorkspace.setBackground(UITheme.BG_CANVAS);
        centerWorkspace.setBorder(BorderFactory.createEmptyBorder(30, 64, 26, 64));

        // 2A. Elevated Question Statement Card
        UITheme.RoundedPanel questionCard = new UITheme.RoundedPanel(
                new BorderLayout(0, 12), 16, UITheme.BG_CARD, UITheme.BORDER_CARD, 26, 32
        );

        JPanel questionMetaRow = new JPanel(new BorderLayout());
        questionMetaRow.setOpaque(false);

        UITheme.PillBadge marksPill = new UITheme.PillBadge(
                "+" + quizConfig.getMarksPerQuestion() + " Marks   •   -" + quizConfig.getNegativeMarks() + " Negative",
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );
        questionMetaRow.add(marksPill, BorderLayout.WEST);

        questionTextLabel = new JLabel();
        questionTextLabel.setFont(UITheme.FONT_SECTION);
        questionTextLabel.setForeground(UITheme.TEXT_PRIMARY);

        questionCard.add(questionMetaRow, BorderLayout.NORTH);
        questionCard.add(questionTextLabel, BorderLayout.CENTER);
        centerWorkspace.add(questionCard, BorderLayout.NORTH);

        // 2B. 4 Clickable OptionCards (A, B, C, D)
        JPanel optionsGrid = new JPanel(new GridLayout(4, 1, 0, 14));
        optionsGrid.setBackground(UITheme.BG_CANVAS);

        optionCards = new UITheme.OptionCard[4];
        char[] letters = {'A', 'B', 'C', 'D'};

        for (int i = 0; i < 4; i++) {
            final int optionIndex = i;
            optionCards[i] = new UITheme.OptionCard(letters[i], new Runnable() {
                @Override
                public void run() {
                    selectOptionCard(optionIndex);
                }
            });
            optionsGrid.add(optionCards[i]);
        }

        centerWorkspace.add(optionsGrid, BorderLayout.CENTER);
        add(centerWorkspace, BorderLayout.CENTER);

        // 3. Bottom Navigation Bar
        add(createBottomActionBar(), BorderLayout.SOUTH);

        // 4. Per-Question Swing Timer (1000ms interval)
        questionTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleTimerTick();
            }
        });

        displayQuestion(currentQuestionIndex);
    }

    /**
     * Builds the top assessment bar with Question Progress and Pill Countdown Timer.
     */
    private JPanel createTopExamHeader() {
        JPanel topWrapper = new JPanel(new BorderLayout());
        topWrapper.setBackground(UITheme.BG_CARD);

        JPanel bar = new JPanel(new BorderLayout(20, 0));
        bar.setBackground(UITheme.BG_CARD);
        bar.setBorder(BorderFactory.createEmptyBorder(16, 48, 16, 48));

        // Left: Subject Name & Candidate
        JPanel leftBox = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftBox.setOpaque(false);

        JLabel subjectTitle = new JLabel(quizConfig.getSubject());
        subjectTitle.setFont(UITheme.FONT_SECTION);
        subjectTitle.setForeground(UITheme.TEXT_PRIMARY);

        UITheme.PillBadge proctorBadge = new UITheme.PillBadge(
                "● PROCTORING ACTIVE",
                UITheme.SUCCESS_SOFT_BG,
                UITheme.SUCCESS_HOVER,
                UITheme.SUCCESS_BORDER
        );

        leftBox.add(subjectTitle);
        leftBox.add(proctorBadge);

        // Center: Question X of N
        progressCounterLabel = new JLabel("Question 1 of " + questions.size(), JLabel.CENTER);
        progressCounterLabel.setFont(UITheme.FONT_HEADING);
        progressCounterLabel.setForeground(UITheme.TEXT_SECONDARY);

        // Right: Pill-Shaped Countdown Timer Badge
        JPanel rightBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightBox.setOpaque(false);

        timerPillBadge = new UITheme.PillBadge(
                "⏱  " + quizConfig.getTimePerQuestionSeconds() + "s remaining",
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );
        timerPillBadge.setFont(UITheme.FONT_BOLD);
        rightBox.add(timerPillBadge);

        bar.add(leftBox, BorderLayout.WEST);
        bar.add(progressCounterLabel, BorderLayout.CENTER);
        bar.add(rightBox, BorderLayout.EAST);

        // Smooth Top Progress Bar
        questionProgressBar = new JProgressBar(0, questions.size());
        questionProgressBar.setValue(1);
        questionProgressBar.setPreferredSize(new Dimension(1120, 5));
        questionProgressBar.setForeground(UITheme.ACCENT_INDIGO);
        questionProgressBar.setBackground(UITheme.BG_SUBTLE);
        questionProgressBar.setBorderPainted(false);

        topWrapper.add(bar, BorderLayout.NORTH);
        topWrapper.add(questionProgressBar, BorderLayout.SOUTH);
        return topWrapper;
    }

    /**
     * Builds the bottom navigation bar with Previous, Clear Selection, Next, and Submit buttons.
     */
    private JPanel createBottomActionBar() {
        JPanel bottomBar = new JPanel(new BorderLayout());
        bottomBar.setBackground(UITheme.BG_CARD);
        bottomBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BORDER_CARD),
                BorderFactory.createEmptyBorder(16, 64, 16, 64)
        ));

        JPanel leftControls = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftControls.setOpaque(false);

        prevButton = UITheme.createSecondaryButton("← Previous");
        prevButton.addActionListener(this);

        clearSelectionButton = UITheme.createSecondaryButton("Clear Response");
        clearSelectionButton.addActionListener(this);

        leftControls.add(prevButton);
        leftControls.add(clearSelectionButton);

        JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        rightControls.setOpaque(false);

        nextButton = UITheme.createPrimaryButton("Next Question →");
        nextButton.addActionListener(this);

        submitButton = UITheme.createSuccessButton("Submit Assessment ✓");
        submitButton.addActionListener(this);

        rightControls.add(nextButton);
        rightControls.add(submitButton);

        bottomBar.add(leftControls, BorderLayout.WEST);
        bottomBar.add(rightControls, BorderLayout.EAST);
        return bottomBar;
    }

    /**
     * Selects one of the 4 custom OptionCards (0 to 3) and updates 'userAnswers'.
     */
    private void selectOptionCard(int selectedIndex) {
        userAnswers[currentQuestionIndex] = selectedIndex;
        for (int i = 0; i < 4; i++) {
            optionCards[i].setSelected(i == selectedIndex);
        }
    }

    /**
     * Loads the question at 'index' into the Question Card and OptionCards, and resets the timer.
     */
    private void displayQuestion(int index) {
        Question q = questions.get(index);

        progressCounterLabel.setText("Question " + (index + 1) + " of " + questions.size());
        questionProgressBar.setValue(index + 1);

        // 1.4 line-spacing via inline CSS for crisp multi-line readability
        questionTextLabel.setText(
                "<html><body style='width: 760px; line-height: 1.45; font-family: Segoe UI;'>"
                        + "Q" + (index + 1) + ". " + q.getQuestionText()
                        + "</body></html>"
        );

        String[] opts = q.getOptions();
        int savedChoice = userAnswers[index];
        for (int i = 0; i < 4; i++) {
            optionCards[i].setOptionText(opts[i]);
            optionCards[i].setSelected(i == savedChoice);
        }

        prevButton.setEnabled(index > 0);
        nextButton.setEnabled(index < questions.size() - 1);

        // Reset per-question timer
        remainingSeconds = quizConfig.getTimePerQuestionSeconds();
        updateTimerBadgeUI();
        questionTimer.restart();
    }

    /**
     * Called every 1 second by javax.swing.Timer.
     */
    private void handleTimerTick() {
        if (isQuizFinished) {
            return;
        }

        remainingSeconds--;
        updateTimerBadgeUI();

        if (remainingSeconds <= 0) {
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                displayQuestion(currentQuestionIndex);
            } else {
                finishQuiz(STATUS_COMPLETED, null);
            }
        }
    }

    /**
     * Updates the pill-shaped countdown timer badge; turns crimson red when <= 5 seconds remain.
     */
    private void updateTimerBadgeUI() {
        String text = "⏱  " + remainingSeconds + "s remaining";
        if (remainingSeconds <= 5) {
            timerPillBadge.setBadgeStyle(
                    text,
                    UITheme.DANGER_SOFT_BG,
                    UITheme.DANGER_HOVER,
                    UITheme.DANGER_BORDER
            );
        } else {
            timerPillBadge.setBadgeStyle(
                    text,
                    UITheme.ACCENT_INDIGO_SOFT,
                    UITheme.ACCENT_INDIGO,
                    UITheme.ACCENT_INDIGO_BDR
            );
        }
    }

    private void finishQuiz(String status, String alertMessage) {
        if (isQuizFinished) {
            return;
        }
        isQuizFinished = true;

        if (questionTimer != null) {
            questionTimer.stop();
        }
        removeWindowFocusListener(this);

        if (alertMessage != null) {
            JOptionPane.showMessageDialog(this,
                    alertMessage,
                    "Proctoring Violation — Auto-Submitted",
                    JOptionPane.ERROR_MESSAGE);
        }

        ResultFrame resultFrame = new ResultFrame(currentUser, quizConfig, questions, userAnswers, status);
        resultFrame.setVisible(true);
        this.dispose();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (isQuizFinished) {
            return;
        }

        if (e.getSource() == prevButton) {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                displayQuestion(currentQuestionIndex);
            }
        } else if (e.getSource() == clearSelectionButton) {
            userAnswers[currentQuestionIndex] = -1;
            for (int i = 0; i < 4; i++) {
                optionCards[i].setSelected(false);
            }
        } else if (e.getSource() == nextButton) {
            if (currentQuestionIndex < questions.size() - 1) {
                currentQuestionIndex++;
                displayQuestion(currentQuestionIndex);
            }
        } else if (e.getSource() == submitButton) {
            finishQuiz(STATUS_COMPLETED, null);
        }
    }

    @Override
    public void windowGainedFocus(WindowEvent e) {
    }

    @Override
    public void windowLostFocus(WindowEvent e) {
        if (!isQuizFinished && this.isVisible()) {
            finishQuiz(
                    STATUS_TAB_SWITCH,
                    "FOCUS LOSS DETECTED: Switching windows or tabs is not permitted during an active assessment.\n"
                            + "Your attempt has been automatically submitted with status:\n"
                            + STATUS_TAB_SWITCH
            );
        }
    }
}
