/**
 * Question.java
 * 
 * VIVA CONCEPT: Encapsulation, Constructors, and 1D Arrays
 * - Represents a single Multiple Choice Question (MCQ) in the quiz.
 * - Uses a String array (String[]) to store the 4 options cleanly.
 * - All fields are 'private' to enforce Encapsulation.
 */
public class Question {

    // Private data members (Encapsulation)
    private String subject;
    private String questionText;
    private String[] options;       // Array storing 4 choices (index 0, 1, 2, 3)
    private int correctOptionIndex; // Stores which index (0 to 3) is the right answer

    /**
     * VIVA CONCEPT: Parameterized Constructor
     * Creates a Question object with all required details.
     * 
     * @param subject            Quiz subject (e.g., "Java Programming")
     * @param questionText       The actual question statement
     * @param options            Array of 4 option strings
     * @param correctOptionIndex Correct option index (0 for Option A, 1 for B, 2 for C, 3 for D)
     */
    public Question(String subject, String questionText, String[] options, int correctOptionIndex) {
        this.subject = subject;
        this.questionText = questionText;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
    }

    // ==================== GETTERS (Encapsulation) ====================

    public String getSubject() {
        return subject;
    }

    public String getQuestionText() {
        return questionText;
    }

    public String[] getOptions() {
        return options;
    }

    public int getCorrectOptionIndex() {
        return correctOptionIndex;
    }

    /**
     * Helper method to check if a user's selected option index is correct.
     * 
     * @param selectedIndex The option index chosen by the student (0 to 3, or -1 if unanswered)
     * @return true if correct, false otherwise
     */
    public boolean isCorrect(int selectedIndex) {
        return this.correctOptionIndex == selectedIndex;
    }

    /**
     * Converts this Question object into a single comma-separated line for 'questions.txt'.
     * Format: subject,questionText,option1,option2,option3,option4,correctOptionIndex
     */
    public String toCsvString() {
        return subject + ","
                + questionText + ","
                + options[0] + ","
                + options[1] + ","
                + options[2] + ","
                + options[3] + ","
                + correctOptionIndex;
    }
}
