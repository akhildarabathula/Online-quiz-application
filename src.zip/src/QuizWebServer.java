import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;

/**
 * QuizWebServer.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Built-in JDK HTTP Server ('com.sun.net.httpserver.HttpServer'):
 *    Uses standard Java networking (zero external JARs or frameworks) bound to 0.0.0.0:8080
 *    so students can take quizzes on both laptop browsers (http://localhost:8080) and
 *    mobile phones over Wi-Fi/Hotspot (http://<PC-IP>:8080).
 * 2. Exam Timing Schedule Enforcement & Bulk Unlocking Endpoints:
 *    - Enforces 'QuizConfig.isAvailableRightNow()' on '/api/quizzes' and '/api/quiz/start'.
 *    - Provides '/api/admin/unlock-all' to unlock all students at once (per subject or globally).
 *    - Provides '/api/admin/toggle-exam' to open/close or update exam timing windows live.
 */
public class QuizWebServer {

    private final int port;
    private HttpServer server;

    /**
     * Inner class representing an active student quiz session on the server.
     */
    private static class ActiveQuizSession {
        String sessionId;
        String username;
        QuizConfig config;
        ArrayList<Question> questions;

        ActiveQuizSession(String sessionId, String username, QuizConfig config, ArrayList<Question> questions) {
            this.sessionId = sessionId;
            this.username = username;
            this.config = config;
            this.questions = questions;
        }
    }

    private static final Map<String, ActiveQuizSession> activeSessions = new ConcurrentHashMap<>();

    public QuizWebServer(int port) {
        this.port = port;
    }

    /**
     * Starts the HTTP server on 0.0.0.0:8080 and prints Laptop + Mobile Wi-Fi URLs.
     */
    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
        server.setExecutor(Executors.newCachedThreadPool());

        // 1. Static Web UI Handler
        server.createContext("/", new StaticFileHandler());

        // 2. Authentication Endpoints
        server.createContext("/api/login", new LoginHandler());
        server.createContext("/api/register", new RegisterHandler());

        // 3. Student Quiz & Proctoring Endpoints
        server.createContext("/api/quizzes", new QuizzesListHandler());
        server.createContext("/api/quiz/start", new QuizStartHandler());
        server.createContext("/api/quiz/submit", new QuizSubmitHandler());

        // 4. Professor / Admin Endpoints
        server.createContext("/api/admin/data", new AdminDataHandler());
        server.createContext("/api/admin/config", new AdminConfigHandler());
        server.createContext("/api/admin/question", new AdminQuestionHandler());
        server.createContext("/api/admin/unlock", new AdminUnlockHandler());
        server.createContext("/api/admin/unlock-all", new AdminUnlockAllHandler());
        server.createContext("/api/admin/toggle-exam", new AdminToggleExamHandler());

        server.start();

        String lanIp = detectLocalWiFiIp();
        System.out.println("======================================================================");
        System.out.println("  ONLINE QUIZ APPLICATION - JAVA WEB SERVER STARTED SUCCESSFULLY!");
        System.out.println("======================================================================");
        System.out.println("  -> Laptop / PC Browser URL : http://localhost:" + port);
        System.out.println("  -> Mobile Phone (Wi-Fi) URL: http://" + lanIp + ":" + port);
        System.out.println("----------------------------------------------------------------------");
        System.out.println("  Demo Accounts:");
        System.out.println("    Professor (Admin) : admin / admin123");
        System.out.println("    Student           : student1 / pass123");
        System.out.println("======================================================================");
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    // =========================================================================
    // HANDLER 1: Static Files (web/index.html, web/style.css, web/app.js)
    // =========================================================================

    private static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            if (path.equals("/") || path.isEmpty()) {
                path = "/index.html";
            }

            if (path.contains("..")) {
                sendText(exchange, 403, "text/plain", "Forbidden");
                return;
            }

            File webFile = resolveWebFile(path.substring(1));
            if (!webFile.exists() || webFile.isDirectory()) {
                sendText(exchange, 404, "text/plain", "404 Not Found: " + path);
                return;
            }

            String contentType = "text/plain; charset=utf-8";
            if (path.endsWith(".html")) {
                contentType = "text/html; charset=utf-8";
            } else if (path.endsWith(".css")) {
                contentType = "text/css; charset=utf-8";
            } else if (path.endsWith(".js")) {
                contentType = "application/javascript; charset=utf-8";
            }

            byte[] bytes = readFileBytes(webFile);
            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.getResponseHeaders().set("Cache-Control", "no-store");
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    // =========================================================================
    // HANDLER 2: POST /api/login
    // =========================================================================

    private static class LoginHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String username = body.getOrDefault("username", "").trim();
            String password = body.getOrDefault("password", "").trim();
            String expectedRole = body.getOrDefault("role", "").trim();

            if (username.isEmpty() || password.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Please enter both username and password.\"}");
                return;
            }

            User user = FileManager.validateLogin(username, password);
            if (user == null) {
                sendJson(exchange, 401, "{\"error\":\"Invalid username or password.\"}");
                return;
            }

            if (!expectedRole.isEmpty() && !user.getRole().equalsIgnoreCase(expectedRole)) {
                sendJson(exchange, 403, "{\"error\":\"Account '" + escapeJson(username)
                        + "' has role " + escapeJson(user.getRole())
                        + ". Please switch the Student / Professor toggle!\"}");
                return;
            }

            String json = "{"
                    + "\"success\":true,"
                    + "\"username\":\"" + escapeJson(user.getUsername()) + "\","
                    + "\"role\":\"" + escapeJson(user.getRole()) + "\""
                    + "}";
            sendJson(exchange, 200, json);
        }
    }

    // =========================================================================
    // HANDLER 3: POST /api/register
    // =========================================================================

    private static class RegisterHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String username = body.getOrDefault("username", "").trim();
            String password = body.getOrDefault("password", "").trim();

            if (username.isEmpty() || password.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Username and password are required.\"}");
                return;
            }
            if (username.contains(",") || password.contains(",")) {
                sendJson(exchange, 400, "{\"error\":\"Username and password cannot contain commas (,).\"}");
                return;
            }

            User newUser = new User(username, password);
            boolean registered = FileManager.registerUser(newUser);

            if (!registered) {
                sendJson(exchange, 409, "{\"error\":\"Username '" + escapeJson(username) + "' is already taken.\"}");
                return;
            }

            String json = "{"
                    + "\"success\":true,"
                    + "\"username\":\"" + escapeJson(newUser.getUsername()) + "\","
                    + "\"role\":\"" + escapeJson(newUser.getRole()) + "\""
                    + "}";
            sendJson(exchange, 200, json);
        }
    }

    // =========================================================================
    // HANDLER 4: GET /api/quizzes?username=...
    // =========================================================================

    private static class QuizzesListHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, String> query = parseQueryParams(exchange.getRequestURI().getRawQuery());
            String username = query.getOrDefault("username", "").trim();

            ArrayList<QuizConfig> configs = FileManager.loadAllQuizConfigs();
            StringBuilder sb = new StringBuilder();
            sb.append("{\"quizzes\":[");

            for (int i = 0; i < configs.size(); i++) {
                QuizConfig cfg = configs.get(i);
                int bankCount = FileManager.loadQuestionsBySubject(cfg.getSubject()).size();
                boolean isLocked = !username.isEmpty() && FileManager.isExamLocked(username, cfg.getSubject());
                boolean availableNow = cfg.isAvailableRightNow();
                String[] latestResult = username.isEmpty()
                        ? null
                        : FileManager.getLatestResultForStudent(username, cfg.getSubject());

                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{")
                  .append("\"subject\":\"").append(escapeJson(cfg.getSubject())).append("\",")
                  .append("\"numQuestionsToPick\":").append(cfg.getNumQuestionsToPick()).append(",")
                  .append("\"timePerQuestionSeconds\":").append(cfg.getTimePerQuestionSeconds()).append(",")
                  .append("\"marksPerQuestion\":").append(cfg.getMarksPerQuestion()).append(",")
                  .append("\"negativeMarks\":").append(cfg.getNegativeMarks()).append(",")
                  .append("\"examActive\":").append(cfg.isExamActive()).append(",")
                  .append("\"examTimeWindow\":\"").append(escapeJson(cfg.getExamTimeWindow())).append("\",")
                  .append("\"startTime\":\"").append(escapeJson(cfg.getStartTimePart())).append("\",")
                  .append("\"endTime\":\"").append(escapeJson(cfg.getEndTimePart())).append("\",")
                  .append("\"formattedTimeWindow\":\"").append(escapeJson(cfg.getFormattedTimeWindow())).append("\",")
                  .append("\"availableNow\":").append(availableNow).append(",")
                  .append("\"bankCount\":").append(bankCount).append(",")
                  .append("\"locked\":").append(isLocked).append(",")
                  .append("\"lastScore\":\"").append(latestResult != null ? escapeJson(latestResult[2]) : "").append("\",")
                  .append("\"lastMaxScore\":\"").append(latestResult != null ? escapeJson(latestResult[3]) : "").append("\",")
                  .append("\"lastStatus\":\"").append(latestResult != null ? escapeJson(latestResult[4]) : "").append("\"")
                  .append("}");
            }

            sb.append("]}");
            sendJson(exchange, 200, sb.toString());
        }
    }

    // =========================================================================
    // HANDLER 5: POST /api/quiz/start
    // =========================================================================

    private static class QuizStartHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String username = body.getOrDefault("username", "").trim();
            String subject = body.getOrDefault("subject", "").trim();

            if (username.isEmpty() || subject.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Username and subject are required.\"}");
                return;
            }

            QuizConfig config = FileManager.getQuizConfigBySubject(subject);

            // 1. Check if Exam is Active AND within the Professor's Scheduled Exam Timing Window
            if (!config.isAvailableRightNow()) {
                String msg = "Closed — Available only during Exam Timings (" + config.getFormattedTimeWindow() + ")";
                sendJson(exchange, 403, "{\"closed\":true,\"error\":\"" + escapeJson(msg) + "\"}");
                return;
            }

            // 2. Check if the student is LOCKED from taking this exam
            if (FileManager.isExamLocked(username, subject)) {
                sendJson(exchange, 403, "{\"locked\":true,\"error\":\"Attempt Locked — Contact Professor to Unlock\"}");
                return;
            }

            // 3. Load & shuffle random subset of questions via Collections.shuffle()
            ArrayList<Question> randomQuestions = FileManager.getQuestionsForQuiz(
                    config.getSubject(),
                    config.getNumQuestionsToPick()
            );

            if (randomQuestions.isEmpty()) {
                sendJson(exchange, 404, "{\"error\":\"No questions found in the bank for this subject.\"}");
                return;
            }

            // 4. Create server-side session
            String sessionId = UUID.randomUUID().toString();
            ActiveQuizSession session = new ActiveQuizSession(sessionId, username, config, randomQuestions);
            activeSessions.put(sessionId, session);

            // 5. Return questions WITHOUT correctOptionIndex
            StringBuilder sb = new StringBuilder();
            sb.append("{")
              .append("\"sessionId\":\"").append(escapeJson(sessionId)).append("\",")
              .append("\"subject\":\"").append(escapeJson(config.getSubject())).append("\",")
              .append("\"timePerQuestionSeconds\":").append(config.getTimePerQuestionSeconds()).append(",")
              .append("\"marksPerQuestion\":").append(config.getMarksPerQuestion()).append(",")
              .append("\"negativeMarks\":").append(config.getNegativeMarks()).append(",")
              .append("\"questions\":[");

            for (int i = 0; i < randomQuestions.size(); i++) {
                Question q = randomQuestions.get(i);
                String[] opts = q.getOptions();
                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{")
                  .append("\"index\":").append(i).append(",")
                  .append("\"questionText\":\"").append(escapeJson(q.getQuestionText())).append("\",")
                  .append("\"options\":[")
                  .append("\"").append(escapeJson(opts[0])).append("\",")
                  .append("\"").append(escapeJson(opts[1])).append("\",")
                  .append("\"").append(escapeJson(opts[2])).append("\",")
                  .append("\"").append(escapeJson(opts[3])).append("\"")
                  .append("]}");
            }

            sb.append("]}");
            sendJson(exchange, 200, sb.toString());
        }
    }

    // =========================================================================
    // HANDLER 6: POST /api/quiz/submit
    // =========================================================================

    private static class QuizSubmitHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String sessionId = body.getOrDefault("sessionId", "").trim();
            String status = body.getOrDefault("status", "COMPLETED").trim();
            String answersRaw = body.getOrDefault("answers", "").trim();

            ActiveQuizSession session = activeSessions.remove(sessionId);
            if (session == null) {
                sendJson(exchange, 404, "{\"error\":\"Quiz session expired or already submitted.\"}");
                return;
            }

            ArrayList<Question> questions = session.questions;
            QuizConfig cfg = session.config;
            int totalQ = questions.size();

            int[] userAnswers = new int[totalQ];
            for (int i = 0; i < totalQ; i++) {
                userAnswers[i] = -1;
            }

            if (!answersRaw.isEmpty()) {
                String[] parts = answersRaw.split(",");
                for (int i = 0; i < Math.min(totalQ, parts.length); i++) {
                    try {
                        userAnswers[i] = Integer.parseInt(parts[i].trim());
                    } catch (NumberFormatException ignored) {
                        userAnswers[i] = -1;
                    }
                }
            }

            int correctCount = 0;
            int wrongCount = 0;
            int unansweredCount = 0;

            for (int i = 0; i < totalQ; i++) {
                int chosen = userAnswers[i];
                if (chosen < 0 || chosen > 3) {
                    unansweredCount++;
                } else if (questions.get(i).isCorrect(chosen)) {
                    correctCount++;
                } else {
                    wrongCount++;
                }
            }

            QuizCalculator calculator = new QuizCalculator();
            double marksPerQ = cfg.getMarksPerQuestion();
            double negMarks = cfg.getNegativeMarks();
            double finalScore;

            if (negMarks > 0) {
                finalScore = calculator.calculateScore(correctCount, wrongCount, marksPerQ, negMarks);
            } else {
                finalScore = calculator.calculateScore(correctCount, marksPerQ);
            }

            finalScore = Math.round(finalScore * 100.0) / 100.0;
            double maxScore = Math.round(calculator.calculateMaxPossibleScore(totalQ, marksPerQ) * 100.0) / 100.0;

            // Lock the student's exam attempt in 'results.txt' (locked = true)
            FileManager.saveResult(session.username, cfg.getSubject(), finalScore, maxScore, status, true);

            StringBuilder sb = new StringBuilder();
            sb.append("{")
              .append("\"username\":\"").append(escapeJson(session.username)).append("\",")
              .append("\"subject\":\"").append(escapeJson(cfg.getSubject())).append("\",")
              .append("\"score\":").append(finalScore).append(",")
              .append("\"maxScore\":").append(maxScore).append(",")
              .append("\"marksPerQuestion\":").append(marksPerQ).append(",")
              .append("\"negativeMarks\":").append(negMarks).append(",")
              .append("\"totalQuestions\":").append(totalQ).append(",")
              .append("\"correctCount\":").append(correctCount).append(",")
              .append("\"wrongCount\":").append(wrongCount).append(",")
              .append("\"unansweredCount\":").append(unansweredCount).append(",")
              .append("\"status\":\"").append(escapeJson(status)).append("\",")
              .append("\"locked\":true,")
              .append("\"responseSheet\":[");

            for (int i = 0; i < totalQ; i++) {
                Question q = questions.get(i);
                String[] opts = q.getOptions();
                int chosen = userAnswers[i];
                int correctIdx = q.getCorrectOptionIndex();
                double marksDelta = (chosen < 0 || chosen > 3)
                        ? 0.0
                        : (chosen == correctIdx ? marksPerQ : -negMarks);

                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{")
                  .append("\"qNumber\":").append(i + 1).append(",")
                  .append("\"questionText\":\"").append(escapeJson(q.getQuestionText())).append("\",")
                  .append("\"options\":[")
                  .append("\"").append(escapeJson(opts[0])).append("\",")
                  .append("\"").append(escapeJson(opts[1])).append("\",")
                  .append("\"").append(escapeJson(opts[2])).append("\",")
                  .append("\"").append(escapeJson(opts[3])).append("\"")
                  .append("],")
                  .append("\"selectedIndex\":").append(chosen).append(",")
                  .append("\"correctIndex\":").append(correctIdx).append(",")
                  .append("\"marksDelta\":").append(marksDelta)
                  .append("}");
            }

            sb.append("]}");
            sendJson(exchange, 200, sb.toString());
        }
    }

    // =========================================================================
    // HANDLER 7: GET /api/admin/data
    // =========================================================================

    private static class AdminDataHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            ArrayList<QuizConfig> configs = FileManager.loadAllQuizConfigs();
            ArrayList<String[]> results = FileManager.loadAllResults();

            StringBuilder sb = new StringBuilder();
            sb.append("{\"configs\":[");

            for (int i = 0; i < configs.size(); i++) {
                QuizConfig cfg = configs.get(i);
                int bankCount = FileManager.loadQuestionsBySubject(cfg.getSubject()).size();
                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{")
                  .append("\"subject\":\"").append(escapeJson(cfg.getSubject())).append("\",")
                  .append("\"numQuestionsToPick\":").append(cfg.getNumQuestionsToPick()).append(",")
                  .append("\"timePerQuestionSeconds\":").append(cfg.getTimePerQuestionSeconds()).append(",")
                  .append("\"marksPerQuestion\":").append(cfg.getMarksPerQuestion()).append(",")
                  .append("\"negativeMarks\":").append(cfg.getNegativeMarks()).append(",")
                  .append("\"examActive\":").append(cfg.isExamActive()).append(",")
                  .append("\"examTimeWindow\":\"").append(escapeJson(cfg.getExamTimeWindow())).append("\",")
                  .append("\"startTime\":\"").append(escapeJson(cfg.getStartTimePart())).append("\",")
                  .append("\"endTime\":\"").append(escapeJson(cfg.getEndTimePart())).append("\",")
                  .append("\"formattedTimeWindow\":\"").append(escapeJson(cfg.getFormattedTimeWindow())).append("\",")
                  .append("\"availableNow\":").append(cfg.isAvailableRightNow()).append(",")
                  .append("\"bankCount\":").append(bankCount)
                  .append("}");
            }

            sb.append("],\"results\":[");

            for (int i = 0; i < results.size(); i++) {
                String[] r = results.get(i);
                boolean locked = Boolean.parseBoolean(r[5]);
                if (i > 0) {
                    sb.append(",");
                }
                sb.append("{")
                  .append("\"username\":\"").append(escapeJson(r[0])).append("\",")
                  .append("\"subject\":\"").append(escapeJson(r[1])).append("\",")
                  .append("\"score\":\"").append(escapeJson(r[2])).append("\",")
                  .append("\"maxScore\":\"").append(escapeJson(r[3])).append("\",")
                  .append("\"status\":\"").append(escapeJson(r[4])).append("\",")
                  .append("\"locked\":").append(locked)
                  .append("}");
            }

            sb.append("]}");
            sendJson(exchange, 200, sb.toString());
        }
    }

    // =========================================================================
    // HANDLER 8: POST /api/admin/config
    // =========================================================================

    private static class AdminConfigHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String subject = body.getOrDefault("subject", "").trim();

            if (subject.isEmpty() || subject.contains(",")) {
                sendJson(exchange, 400, "{\"error\":\"Please provide a valid Subject Name (without commas).\"}");
                return;
            }

            try {
                int numQuestions = Integer.parseInt(body.getOrDefault("numQuestionsToPick", "5").trim());
                int timeSeconds = Integer.parseInt(body.getOrDefault("timePerQuestionSeconds", "15").trim());
                double marksPerQ = Double.parseDouble(body.getOrDefault("marksPerQuestion", "4.0").trim());
                double negMarks = Double.parseDouble(body.getOrDefault("negativeMarks", "0.0").trim());
                boolean examActive = Boolean.parseBoolean(body.getOrDefault("examActive", "true").trim());

                String examTimeWindow = body.getOrDefault("examTimeWindow", "").trim();
                if (examTimeWindow.isEmpty()) {
                    String startTime = body.getOrDefault("startTime", "00:00").trim();
                    String endTime = body.getOrDefault("endTime", "23:59").trim();
                    if (startTime.isEmpty()) startTime = "00:00";
                    if (endTime.isEmpty()) endTime = "23:59";
                    examTimeWindow = startTime + "|" + endTime;
                }

                if (numQuestions <= 0 || timeSeconds < 3 || marksPerQ <= 0 || negMarks < 0) {
                    sendJson(exchange, 400, "{\"error\":\"Questions >= 1, Time >= 3s, Marks/Q > 0, and Negative >= 0.\"}");
                    return;
                }

                QuizConfig cfg = new QuizConfig(
                        subject, numQuestions, timeSeconds, marksPerQ, negMarks, examActive, examTimeWindow
                );
                FileManager.saveOrUpdateQuizConfig(cfg);
                sendJson(exchange, 200, "{\"success\":true}");
            } catch (NumberFormatException e) {
                sendJson(exchange, 400, "{\"error\":\"Invalid number format in configuration fields.\"}");
            }
        }
    }

    // =========================================================================
    // HANDLER 9: POST /api/admin/question
    // =========================================================================

    private static class AdminQuestionHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String subject = body.getOrDefault("subject", "").trim();
            String questionText = body.getOrDefault("questionText", "").trim();
            String optA = body.getOrDefault("optionA", "").trim();
            String optB = body.getOrDefault("optionB", "").trim();
            String optC = body.getOrDefault("optionC", "").trim();
            String optD = body.getOrDefault("optionD", "").trim();

            if (subject.isEmpty() || questionText.isEmpty() || optA.isEmpty() || optB.isEmpty() || optC.isEmpty() || optD.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Please fill in the question statement and all 4 options.\"}");
                return;
            }

            if (questionText.contains(",") || optA.contains(",") || optB.contains(",") || optC.contains(",") || optD.contains(",")) {
                sendJson(exchange, 400, "{\"error\":\"Commas (,) are not allowed in question or option text (CSV storage).\"}");
                return;
            }

            try {
                int correctIndex = Integer.parseInt(body.getOrDefault("correctOptionIndex", "0").trim());
                if (correctIndex < 0 || correctIndex > 3) {
                    correctIndex = 0;
                }

                Question q = new Question(subject, questionText, new String[]{optA, optB, optC, optD}, correctIndex);
                FileManager.addQuestionToFile(q);
                sendJson(exchange, 200, "{\"success\":true}");
            } catch (NumberFormatException e) {
                sendJson(exchange, 400, "{\"error\":\"Invalid correct option index.\"}");
            }
        }
    }

    // =========================================================================
    // HANDLER 10: POST /api/admin/unlock (Individual Student Unlock)
    // =========================================================================

    private static class AdminUnlockHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String username = body.getOrDefault("username", "").trim();
            String subject = body.getOrDefault("subject", "").trim();

            if (username.isEmpty() || subject.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Username and subject are required to unlock.\"}");
                return;
            }

            boolean unlocked = FileManager.unlockExamForStudent(username, subject);
            if (unlocked) {
                sendJson(exchange, 200, "{\"success\":true}");
            } else {
                sendJson(exchange, 404, "{\"error\":\"No matching locked record found for this student and subject.\"}");
            }
        }
    }

    // =========================================================================
    // HANDLER 11: POST /api/admin/unlock-all (Bulk Unlock All Students at Once)
    // =========================================================================

    private static class AdminUnlockAllHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String subject = body.getOrDefault("subject", "ALL").trim();

            int unlockedCount;
            if (subject.isEmpty() || "ALL".equalsIgnoreCase(subject)) {
                unlockedCount = FileManager.unlockAllStudentsGlobally();
                subject = "ALL SUBJECTS";
            } else {
                unlockedCount = FileManager.unlockAllStudentsForSubject(subject);
            }

            String json = "{"
                    + "\"success\":true,"
                    + "\"unlockedCount\":" + unlockedCount + ","
                    + "\"subject\":\"" + escapeJson(subject) + "\""
                    + "}";
            sendJson(exchange, 200, json);
        }
    }

    // =========================================================================
    // HANDLER 12: POST /api/admin/toggle-exam (Live Open/Close or Update Schedule)
    // =========================================================================

    private static class AdminToggleExamHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJson(exchange, 405, "{\"error\":\"Method not allowed\"}");
                return;
            }

            Map<String, String> body = parseFormOrJsonBody(readRequestBody(exchange));
            String subject = body.getOrDefault("subject", "").trim();
            if (subject.isEmpty()) {
                sendJson(exchange, 400, "{\"error\":\"Subject is required.\"}");
                return;
            }

            boolean examActive = Boolean.parseBoolean(body.getOrDefault("examActive", "true").trim());
            String examTimeWindow = body.getOrDefault("examTimeWindow", "").trim();

            boolean updated = FileManager.updateExamScheduleAndStatus(subject, examActive, examTimeWindow);
            if (updated) {
                sendJson(exchange, 200, "{\"success\":true}");
            } else {
                sendJson(exchange, 500, "{\"error\":\"Failed to update exam status.\"}");
            }
        }
    }

    // =========================================================================
    // UTILITY & HELPER METHODS
    // =========================================================================

    private static File resolveWebFile(String relativePath) {
        File direct = new File("web", relativePath);
        if (direct.exists()) {
            return direct;
        }
        File parentWeb = new File("../web", relativePath);
        if (parentWeb.exists()) {
            return parentWeb;
        }
        return direct;
    }

    private static byte[] readFileBytes(File file) throws IOException {
        try (InputStream is = new FileInputStream(file);
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[4096];
            int n;
            while ((n = is.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
            }
            return buffer.toByteArray();
        }
    }

    private static String readRequestBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
            byte[] chunk = new byte[2048];
            int n;
            while ((n = is.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
            }
            return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static Map<String, String> parseFormOrJsonBody(String raw) {
        Map<String, String> map = new HashMap<>();
        if (raw == null) {
            return map;
        }
        String trimmed = raw.trim();
        if (trimmed.isEmpty()) {
            return map;
        }

        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            String inner = trimmed.substring(1, trimmed.length() - 1).trim();
            boolean inQuotes = false;
            boolean escaping = false;
            StringBuilder token = new StringBuilder();
            ArrayList<String> pairs = new ArrayList<>();

            for (int i = 0; i < inner.length(); i++) {
                char c = inner.charAt(i);
                if (escaping) {
                    token.append(c);
                    escaping = false;
                } else if (c == '\\') {
                    escaping = true;
                } else if (c == '"') {
                    inQuotes = !inQuotes;
                } else if (c == ',' && !inQuotes) {
                    pairs.add(token.toString());
                    token.setLength(0);
                } else {
                    token.append(c);
                }
            }
            if (token.length() > 0) {
                pairs.add(token.toString());
            }

            for (String pair : pairs) {
                int colon = pair.indexOf(':');
                if (colon > 0) {
                    String k = pair.substring(0, colon).trim();
                    String v = pair.substring(colon + 1).trim();
                    map.put(k, v);
                }
            }
            return map;
        }

        return parseQueryParams(trimmed);
    }

    private static Map<String, String> parseQueryParams(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.isEmpty()) {
            return map;
        }
        String[] pairs = query.split("&");
        for (String pair : pairs) {
            int idx = pair.indexOf('=');
            if (idx > 0) {
                String key = urlDecode(pair.substring(0, idx));
                String val = urlDecode(pair.substring(idx + 1));
                map.put(key, val);
            }
        }
        return map;
    }

    private static String urlDecode(String s) {
        try {
            return URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private static void sendJson(HttpExchange exchange, int statusCode, String jsonBody) throws IOException {
        sendText(exchange, statusCode, "application/json; charset=utf-8", jsonBody);
    }

    private static void sendText(HttpExchange exchange, int statusCode, String contentType, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String escapeJson(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

    public static String detectLocalWiFiIp() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                if (iface.isLoopback() || !iface.isUp()) {
                    continue;
                }
                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress addr = addresses.nextElement();
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        String ip = addr.getHostAddress();
                        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                            return ip;
                        }
                    }
                }
            }
            return InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            return "127.0.0.1";
        }
    }
}
