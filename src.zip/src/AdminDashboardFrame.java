import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/**
 * AdminDashboardFrame.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. SaaS Top Navigation Bar with Pill Tabs + CardLayout:
 *    Switches smoothly between 'Configure Quiz', 'Question Bank', and 'Student Results'
 *    without blocky default Swing tabs.
 * 2. Rounded Card Containers (UITheme.RoundedPanel):
 *    Clean white cards (#FFFFFF) with 16px rounded corners on a #F8FAFC canvas.
 * 3. Configurable Assessment Engine:
 *    Professor controls Random Questions Picked, Seconds per Question, Marks per Question,
 *    and Negative Marking Penalty in 'quiz_config.txt'.
 */
public class AdminDashboardFrame extends JFrame implements ActionListener {

    private static final String VIEW_CONFIG = "CONFIG";
    private static final String VIEW_QUESTIONS = "QUESTIONS";
    private static final String VIEW_RESULTS = "RESULTS";

    private User adminUser;

    // Top Navigation Pill Buttons & CardLayout
    private UITheme.ModernButton navConfigBtn;
    private UITheme.ModernButton navQuestionsBtn;
    private UITheme.ModernButton navResultsBtn;
    private UITheme.ModernButton logoutButton;
    private CardLayout contentCardLayout;
    private JPanel mainContentContainer;

    // View 1: Configure Quiz Components
    private JComboBox<String> existingSubjectCombo;
    private UITheme.ModernTextField subjectNameField;
    private UITheme.ModernTextField numQuestionsField;
    private UITheme.ModernTextField timeSecondsField;
    private UITheme.ModernTextField marksPerQuestionField;
    private UITheme.ModernTextField negativeMarksField;
    private UITheme.ModernButton saveConfigButton;
    private DefaultTableModel configTableModel;

    // View 2: Question Bank Components
    private JComboBox<String> targetSubjectCombo;
    private UITheme.ModernTextField questionTextField;
    private UITheme.ModernTextField optionAField;
    private UITheme.ModernTextField optionBField;
    private UITheme.ModernTextField optionCField;
    private UITheme.ModernTextField optionDField;
    private JComboBox<String> correctOptionCombo;
    private UITheme.ModernButton addQuestionButton;

    // View 3: Student Results Components
    private DefaultTableModel resultsTableModel;
    private UITheme.ModernButton refreshResultsButton;

    /**
     * Constructor: Builds the 1100x750 Professor SaaS Workspace.
     */
    public AdminDashboardFrame(User adminUser) {
        this.adminUser = adminUser;

        setTitle("QuizFlow — Professor & Examination Control Center");
        setSize(1120, 760);
        setMinimumSize(new Dimension(1100, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG_CANVAS);

        // 1. Top SaaS Navigation Bar with Pill Tabs
        add(createTopNavBar(), BorderLayout.NORTH);

        // 2. Center CardLayout Workspace with 35px outer whitespace
        contentCardLayout = new CardLayout();
        mainContentContainer = new JPanel(contentCardLayout);
        mainContentContainer.setBackground(UITheme.BG_CANVAS);
        mainContentContainer.setBorder(BorderFactory.createEmptyBorder(28, 38, 32, 38));

        mainContentContainer.add(createConfigureQuizView(), VIEW_CONFIG);
        mainContentContainer.add(createQuestionBankView(), VIEW_QUESTIONS);
        mainContentContainer.add(createStudentResultsView(), VIEW_RESULTS);

        add(mainContentContainer, BorderLayout.CENTER);

        refreshSubjectDropdownsAndTable();
        refreshStudentResultsTable();
        switchTab(VIEW_CONFIG);
    }

    /**
     * Builds the sleek top navigation bar with brand title, center tab pills, and right logout button.
     */
    private JPanel createTopNavBar() {
        JPanel navBar = new JPanel(new BorderLayout());
        navBar.setBackground(UITheme.BG_CARD);
        navBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CARD),
                BorderFactory.createEmptyBorder(14, 38, 14, 38)
        ));

        // Left: Brand + Admin Badge
        JPanel brandLeft = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        brandLeft.setOpaque(false);

        JLabel appTitle = new JLabel("QuizFlow Studio");
        appTitle.setFont(UITheme.FONT_SECTION);
        appTitle.setForeground(UITheme.TEXT_PRIMARY);

        UITheme.PillBadge rolePill = new UITheme.PillBadge(
                "PROFESSOR • " + adminUser.getUsername().toUpperCase(),
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );

        brandLeft.add(appTitle);
        brandLeft.add(rolePill);

        // Center: Segmented Navigation Pills
        UITheme.RoundedPanel pillBar = new UITheme.RoundedPanel(
                new FlowLayout(FlowLayout.CENTER, 6, 0), 12, UITheme.BG_SUBTLE, UITheme.BORDER_CARD, 4, 6
        );

        navConfigBtn = UITheme.createPrimaryButton("Configure Quiz");
        navQuestionsBtn = UITheme.createSecondaryButton("Question Bank");
        navResultsBtn = UITheme.createSecondaryButton("Student Results");

        navConfigBtn.addActionListener(e -> switchTab(VIEW_CONFIG));
        navQuestionsBtn.addActionListener(e -> switchTab(VIEW_QUESTIONS));
        navResultsBtn.addActionListener(e -> switchTab(VIEW_RESULTS));

        pillBar.add(navConfigBtn);
        pillBar.add(navQuestionsBtn);
        pillBar.add(navResultsBtn);

        // Right: Logout Button
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        rightPanel.setOpaque(false);
        logoutButton = UITheme.createDangerButton("Sign Out");
        logoutButton.addActionListener(this);
        rightPanel.add(logoutButton);

        navBar.add(brandLeft, BorderLayout.WEST);
        navBar.add(pillBar, BorderLayout.CENTER);
        navBar.add(rightPanel, BorderLayout.EAST);

        return navBar;
    }

    /**
     * Switches the active view in CardLayout and highlights the active navigation pill.
     */
    private void switchTab(String viewName) {
        contentCardLayout.show(mainContentContainer, viewName);

        resetNavPill(navConfigBtn, VIEW_CONFIG.equals(viewName));
        resetNavPill(navQuestionsBtn, VIEW_QUESTIONS.equals(viewName));
        resetNavPill(navResultsBtn, VIEW_RESULTS.equals(viewName));

        if (VIEW_RESULTS.equals(viewName)) {
            refreshStudentResultsTable();
        }
    }

    private void resetNavPill(UITheme.ModernButton btn, boolean active) {
        if (active) {
            btn.setColors(UITheme.ACCENT_INDIGO, UITheme.ACCENT_INDIGO_HOVER, Color.WHITE, null);
        } else {
            btn.setColors(UITheme.BG_SUBTLE, UITheme.BG_CARD, UITheme.TEXT_SECONDARY, null);
        }
    }

    /**
     * View 1: Create or update subject rules and inspect active configurations.
     */
    private JPanel createConfigureQuizView() {
        JPanel view = new JPanel(new BorderLayout(0, 22));
        view.setOpaque(false);

        // Top Rounded Card: Configuration Form
        UITheme.RoundedPanel formCard = UITheme.createCardPanel(new BorderLayout(0, 16), 24, 28);

        JPanel cardHeader = new JPanel(new BorderLayout(0, 4));
        cardHeader.setOpaque(false);
        JLabel title = new JLabel("Assessment Rules & Marking Configuration");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        JLabel sub = new JLabel("Create a new examination subject or update timers, question count, positive marks, and negative marking.");
        sub.setFont(UITheme.FONT_SUBTITLE);
        sub.setForeground(UITheme.TEXT_MUTED);
        cardHeader.add(title, BorderLayout.NORTH);
        cardHeader.add(sub, BorderLayout.SOUTH);
        formCard.add(cardHeader, BorderLayout.NORTH);

        JPanel gridForm = new JPanel(new GridBagLayout());
        gridForm.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 10, 6, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: Load Preset Subject or Subject Name
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.25;
        gridForm.add(createFieldLabel("Select Preset / Action"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.25;
        gridForm.add(createFieldLabel("Subject Title"), gbc);
        gbc.gridx = 2; gbc.gridy = 0; gbc.weightx = 0.25;
        gridForm.add(createFieldLabel("Random Questions Picked"), gbc);
        gbc.gridx = 3; gbc.gridy = 0; gbc.weightx = 0.25;
        gridForm.add(createFieldLabel("Time per Question (sec)"), gbc);

        existingSubjectCombo = new JComboBox<>();
        UITheme.styleComboBox(existingSubjectCombo);
        existingSubjectCombo.addActionListener(e -> populateConfigFieldsFromSelection());
        gbc.gridx = 0; gbc.gridy = 1;
        gridForm.add(existingSubjectCombo, gbc);

        subjectNameField = new UITheme.ModernTextField(14);
        gbc.gridx = 1; gbc.gridy = 1;
        gridForm.add(subjectNameField, gbc);

        numQuestionsField = new UITheme.ModernTextField("5", 8);
        gbc.gridx = 2; gbc.gridy = 1;
        gridForm.add(numQuestionsField, gbc);

        timeSecondsField = new UITheme.ModernTextField("15", 8);
        gbc.gridx = 3; gbc.gridy = 1;
        gridForm.add(timeSecondsField, gbc);

        // Row 2: Marks per Question, Negative Penalty, Save Button
        gbc.gridx = 0; gbc.gridy = 2;
        gridForm.add(createFieldLabel("Marks per Correct Answer (+)"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        gridForm.add(createFieldLabel("Negative Penalty per Wrong (-)"), gbc);

        marksPerQuestionField = new UITheme.ModernTextField("4.0", 8);
        gbc.gridx = 0; gbc.gridy = 3;
        gridForm.add(marksPerQuestionField, gbc);

        negativeMarksField = new UITheme.ModernTextField("1.0", 8);
        gbc.gridx = 1; gbc.gridy = 3;
        gridForm.add(negativeMarksField, gbc);

        saveConfigButton = UITheme.createPrimaryButton("Save Subject Configuration");
        saveConfigButton.setPreferredSize(new Dimension(240, 42));
        saveConfigButton.addActionListener(this);
        gbc.gridx = 2; gbc.gridy = 3; gbc.gridwidth = 2;
        gridForm.add(saveConfigButton, gbc);

        formCard.add(gridForm, BorderLayout.CENTER);
        view.add(formCard, BorderLayout.NORTH);

        // Bottom Rounded Card: Live Table of Configured Subjects
        UITheme.RoundedPanel tableCard = UITheme.createCardPanel(new BorderLayout(0, 12), 20, 24);
        JLabel tableTitle = new JLabel("Active Subject Configurations (quiz_config.txt)");
        tableTitle.setFont(UITheme.FONT_HEADING);
        tableTitle.setForeground(UITheme.TEXT_PRIMARY);
        tableCard.add(tableTitle, BorderLayout.NORTH);

        String[] cols = {
            "Subject Title",
            "Random Questions",
            "Timer / Question",
            "Positive Marks (+)",
            "Negative Penalty (-)",
            "Total Bank Size"
        };
        configTableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };

        JTable configTable = new JTable(configTableModel);
        JScrollPane scrollPane = new JScrollPane(configTable);
        UITheme.styleModernTable(configTable, scrollPane);

        tableCard.add(scrollPane, BorderLayout.CENTER);
        view.add(tableCard, BorderLayout.CENTER);

        return view;
    }

    /**
     * View 2: Add new Multiple Choice Questions to 'questions.txt'.
     */
    private JPanel createQuestionBankView() {
        JPanel view = new JPanel(new BorderLayout());
        view.setOpaque(false);

        UITheme.RoundedPanel formCard = UITheme.createCardPanel(new BorderLayout(0, 20), 28, 34);

        JPanel header = new JPanel(new BorderLayout(0, 4));
        header.setOpaque(false);
        JLabel title = new JLabel("Add New Multiple Choice Question to Bank");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        JLabel sub = new JLabel("Questions are stored in questions.txt and automatically shuffled during student attempts.");
        sub.setFont(UITheme.FONT_SUBTITLE);
        sub.setForeground(UITheme.TEXT_MUTED);
        header.add(title, BorderLayout.NORTH);
        header.add(sub, BorderLayout.SOUTH);
        formCard.add(header, BorderLayout.NORTH);

        JPanel formGrid = new JPanel(new GridBagLayout());
        formGrid.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Target Subject & Correct Answer Selector
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.5;
        formGrid.add(createFieldLabel("Target Subject"), gbc);
        gbc.gridx = 1; gbc.gridy = 0; gbc.weightx = 0.5;
        formGrid.add(createFieldLabel("Correct Answer Option"), gbc);

        targetSubjectCombo = new JComboBox<>();
        UITheme.styleComboBox(targetSubjectCombo);
        gbc.gridx = 0; gbc.gridy = 1;
        formGrid.add(targetSubjectCombo, gbc);

        correctOptionCombo = new JComboBox<>(new String[] {
            "Option A (Index 0)",
            "Option B (Index 1)",
            "Option C (Index 2)",
            "Option D (Index 3)"
        });
        UITheme.styleComboBox(correctOptionCombo);
        gbc.gridx = 1; gbc.gridy = 1;
        formGrid.add(correctOptionCombo, gbc);

        // Question Statement (Full Width)
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        formGrid.add(createFieldLabel("Question Statement (avoid commas)"), gbc);

        questionTextField = new UITheme.ModernTextField();
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        formGrid.add(questionTextField, gbc);

        // Options A & B
        gbc.gridwidth = 1;
        gbc.gridx = 0; gbc.gridy = 4;
        formGrid.add(createFieldLabel("Option A"), gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        formGrid.add(createFieldLabel("Option B"), gbc);

        optionAField = new UITheme.ModernTextField();
        gbc.gridx = 0; gbc.gridy = 5;
        formGrid.add(optionAField, gbc);

        optionBField = new UITheme.ModernTextField();
        gbc.gridx = 1; gbc.gridy = 5;
        formGrid.add(optionBField, gbc);

        // Options C & D
        gbc.gridx = 0; gbc.gridy = 6;
        formGrid.add(createFieldLabel("Option C"), gbc);
        gbc.gridx = 1; gbc.gridy = 6;
        formGrid.add(createFieldLabel("Option D"), gbc);

        optionCField = new UITheme.ModernTextField();
        gbc.gridx = 0; gbc.gridy = 7;
        formGrid.add(optionCField, gbc);

        optionDField = new UITheme.ModernTextField();
        gbc.gridx = 1; gbc.gridy = 7;
        formGrid.add(optionDField, gbc);

        // Submit Button Row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 8));
        btnRow.setOpaque(false);
        addQuestionButton = UITheme.createSuccessButton("+ Add Question to Bank");
        addQuestionButton.setPreferredSize(new Dimension(240, 44));
        addQuestionButton.addActionListener(this);
        btnRow.add(addQuestionButton);

        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2;
        formGrid.add(btnRow, gbc);

        formCard.add(formGrid, BorderLayout.CENTER);
        view.add(formCard, BorderLayout.NORTH);

        return view;
    }

    /**
     * View 3: Styled JTable inside a RoundedPanel showing all student attempts and anti-cheat status.
     */
    private JPanel createStudentResultsView() {
        UITheme.RoundedPanel card = UITheme.createCardPanel(new BorderLayout(0, 16), 24, 28);

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JPanel titleBox = new JPanel(new BorderLayout(0, 4));
        titleBox.setOpaque(false);
        JLabel title = new JLabel("Student Assessment Records & Anti-Cheat Audit Log");
        title.setFont(UITheme.FONT_SECTION);
        title.setForeground(UITheme.TEXT_PRIMARY);
        JLabel sub = new JLabel("Live records read from results.txt including completed exams and tab-switch auto-submissions.");
        sub.setFont(UITheme.FONT_SUBTITLE);
        sub.setForeground(UITheme.TEXT_MUTED);
        titleBox.add(title, BorderLayout.NORTH);
        titleBox.add(sub, BorderLayout.SOUTH);

        refreshResultsButton = UITheme.createPrimaryButton("Refresh Records");
        refreshResultsButton.addActionListener(this);

        topBar.add(titleBox, BorderLayout.WEST);
        topBar.add(refreshResultsButton, BorderLayout.EAST);
        card.add(topBar, BorderLayout.NORTH);

        String[] columns = {
            "Candidate Username",
            "Subject Attempted",
            "Final Score",
            "Questions in Attempt",
            "Proctoring / Submission Status"
        };

        resultsTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable resultsTable = new JTable(resultsTableModel);
        JScrollPane scrollPane = new JScrollPane(resultsTable);
        UITheme.styleModernTable(resultsTable, scrollPane);

        card.add(scrollPane, BorderLayout.CENTER);
        return card;
    }

    private JLabel createFieldLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.LEFT);
        label.setFont(UITheme.FONT_BOLD);
        label.setForeground(UITheme.TEXT_SECONDARY);
        return label;
    }

    private void refreshSubjectDropdownsAndTable() {
        ArrayList<QuizConfig> configs = FileManager.loadAllQuizConfigs();

        existingSubjectCombo.removeAllItems();
        existingSubjectCombo.addItem("+ Create New Subject");
        targetSubjectCombo.removeAllItems();
        configTableModel.setRowCount(0);

        for (QuizConfig cfg : configs) {
            existingSubjectCombo.addItem(cfg.getSubject());
            targetSubjectCombo.addItem(cfg.getSubject());

            int bankCount = FileManager.loadQuestionsBySubject(cfg.getSubject()).size();
            configTableModel.addRow(new Object[] {
                cfg.getSubject(),
                cfg.getNumQuestionsToPick() + " Qs",
                cfg.getTimePerQuestionSeconds() + " sec / Q",
                "+" + cfg.getMarksPerQuestion(),
                "-" + cfg.getNegativeMarks(),
                bankCount + " MCQs in bank"
            });
        }
    }

    private void populateConfigFieldsFromSelection() {
        int idx = existingSubjectCombo.getSelectedIndex();
        if (idx <= 0) {
            subjectNameField.setText("");
            numQuestionsField.setText("5");
            timeSecondsField.setText("15");
            marksPerQuestionField.setText("4.0");
            negativeMarksField.setText("1.0");
            return;
        }

        String selectedSubject = (String) existingSubjectCombo.getSelectedItem();
        QuizConfig cfg = FileManager.getQuizConfigBySubject(selectedSubject);
        subjectNameField.setText(cfg.getSubject());
        numQuestionsField.setText(String.valueOf(cfg.getNumQuestionsToPick()));
        timeSecondsField.setText(String.valueOf(cfg.getTimePerQuestionSeconds()));
        marksPerQuestionField.setText(String.valueOf(cfg.getMarksPerQuestion()));
        negativeMarksField.setText(String.valueOf(cfg.getNegativeMarks()));
    }

    private void refreshStudentResultsTable() {
        resultsTableModel.setRowCount(0);
        ArrayList<String[]> rows = FileManager.loadAllResults();
        for (String[] row : rows) {
            resultsTableModel.addRow(row);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == saveConfigButton) {
            handleSaveQuizConfig();
        } else if (e.getSource() == addQuestionButton) {
            handleAddQuestion();
        } else if (e.getSource() == refreshResultsButton) {
            refreshStudentResultsTable();
        } else if (e.getSource() == logoutButton) {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            this.dispose();
        }
    }

    private void handleSaveQuizConfig() {
        String subject = subjectNameField.getText().trim();
        if (subject.isEmpty() || subject.contains(",")) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a valid Subject Title (without commas).",
                    "Invalid Subject",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            int numQuestions = Integer.parseInt(numQuestionsField.getText().trim());
            int timeSeconds = Integer.parseInt(timeSecondsField.getText().trim());
            double marksPerQuestion = Double.parseDouble(marksPerQuestionField.getText().trim());
            double negativeMarks = Double.parseDouble(negativeMarksField.getText().trim());

            if (numQuestions <= 0 || timeSeconds < 3 || marksPerQuestion <= 0 || negativeMarks < 0) {
                JOptionPane.showMessageDialog(this,
                        "Questions >= 1, Time >= 3s, Marks/Question > 0, and Negative Penalty >= 0.",
                        "Validation Error",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            QuizConfig config = new QuizConfig(
                    subject, numQuestions, timeSeconds, marksPerQuestion, negativeMarks);

            if (FileManager.saveOrUpdateQuizConfig(config)) {
                refreshSubjectDropdownsAndTable();
                JOptionPane.showMessageDialog(this,
                        "Saved configuration for '" + subject + "'!\n"
                                + "Questions: " + numQuestions
                                + " | Timer: " + timeSeconds + "s/Q"
                                + " | Marks: +" + marksPerQuestion
                                + " | Negative: -" + negativeMarks,
                        "Configuration Updated",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid numbers for Questions, Time, Marks/Q, and Negative Marks.",
                    "Number Format Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleAddQuestion() {
        String subject = (String) targetSubjectCombo.getSelectedItem();
        if (subject == null || subject.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please create or select a subject first.",
                    "No Subject Selected",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String qText = questionTextField.getText().trim();
        String optA = optionAField.getText().trim();
        String optB = optionBField.getText().trim();
        String optC = optionCField.getText().trim();
        String optD = optionDField.getText().trim();

        if (qText.isEmpty() || optA.isEmpty() || optB.isEmpty() || optC.isEmpty() || optD.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in the question statement and all 4 options.",
                    "Incomplete Question",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (qText.contains(",") || optA.contains(",") || optB.contains(",") || optC.contains(",") || optD.contains(",")) {
            JOptionPane.showMessageDialog(this,
                    "Please avoid commas (,) in the question or options (stored in CSV format).",
                    "Comma Not Allowed",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int correctIndex = correctOptionCombo.getSelectedIndex();
        String[] options = new String[] { optA, optB, optC, optD };
        Question newQuestion = new Question(subject, qText, options, correctIndex);

        if (FileManager.addQuestionToFile(newQuestion)) {
            questionTextField.setText("");
            optionAField.setText("");
            optionBField.setText("");
            optionCField.setText("");
            optionDField.setText("");
            correctOptionCombo.setSelectedIndex(0);
            refreshSubjectDropdownsAndTable();

            JOptionPane.showMessageDialog(this,
                    "Added question to '" + subject + "' bank!",
                    "Question Added",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
