/**
 * QuizCalculator.java
 * 
 * VIVA CONCEPT: Compile-Time Polymorphism (Method Overloading)
 * - Method Overloading occurs when a class has multiple methods with the SAME name
 *   ('calculateScore') but DIFFERENT parameter lists.
 * - Uses the Admin's configurable 'marksPerQuestion' and 'negativeMarks' settings.
 */
public class QuizCalculator {

    /**
     * OVERLOADED METHOD 1: Standard Scoring (No Negative Marking)
     * Formula: correctAnswers * marksPerQuestion
     * 
     * @param correctAnswers   Number of questions answered correctly
     * @param marksPerQuestion Marks awarded for each correct answer (from QuizConfig)
     * @return Total score earned
     */
    public double calculateScore(int correctAnswers, double marksPerQuestion) {
        return correctAnswers * marksPerQuestion;
    }

    /**
     * OVERLOADED METHOD 2: Scoring with Negative Marking
     * Formula: (correctAnswers * marksPerQuestion) - (wrongAnswers * negativeMarks)
     * 
     * @param correctAnswers   Number of questions answered correctly
     * @param wrongAnswers     Number of questions answered incorrectly
     * @param marksPerQuestion Marks awarded for each correct answer (from QuizConfig)
     * @param negativeMarks    Marks deducted for each wrong answer (from QuizConfig)
     * @return Total score after deducting negative marks
     */
    public double calculateScore(int correctAnswers, int wrongAnswers,
                                 double marksPerQuestion, double negativeMarks) {
        double positiveScore = correctAnswers * marksPerQuestion;
        double penalty = wrongAnswers * negativeMarks;
        return positiveScore - penalty;
    }

    /**
     * Calculates the maximum possible score for the quiz.
     * Formula: totalQuestions * marksPerQuestion
     * 
     * @param totalQuestions   Total number of questions in the quiz
     * @param marksPerQuestion Marks awarded per question
     * @return Maximum possible marks
     */
    public double calculateMaxPossibleScore(int totalQuestions, double marksPerQuestion) {
        return totalQuestions * marksPerQuestion;
    }
}
