/**
 * User.java
 * 
 * VIVA CONCEPTS: Inheritance, Encapsulation & Constructor Overloading
 * - Inheritance: 'User extends Person' means User inherits 'username' and 'getUsername()'
 *   from the parent class (Person).
 * - Encapsulation: Private fields 'password' and 'role' with public getters and setters.
 * - Constructor Overloading: Two constructors — one that accepts (username, password, role)
 *   and another that accepts (username, password) and defaults the role to "STUDENT".
 */
public class User extends Person {

    // Role constants for clarity
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_STUDENT = "STUDENT";

    // Private fields specific to a User (Encapsulation)
    private String password;
    private String role; // Either "ADMIN" (Professor) or "STUDENT"

    /**
     * Constructor 1 (Full Constructor):
     * Initializes username (via Person's super constructor), password, and role.
     * 
     * @param username The user's login name
     * @param password The user's login password
     * @param role     The user's role ("ADMIN" or "STUDENT")
     */
    public User(String username, String password, String role) {
        super(username); // Calls the constructor of the parent class (Person)
        this.password = password;
        this.role = role.toUpperCase();
    }

    /**
     * Constructor 2 (Overloaded Constructor):
     * Defaults new registrations to the "STUDENT" role when role is not specified.
     * 
     * @param username The user's login name
     * @param password The user's login password
     */
    public User(String username, String password) {
        this(username, password, ROLE_STUDENT); // Calls Constructor 1 with "STUDENT"
    }

    // ==================== GETTERS & SETTERS ====================

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role.toUpperCase();
    }

    /**
     * Helper method to check if this user is a Professor/Admin.
     * @return true if role is ADMIN, false otherwise
     */
    public boolean isAdmin() {
        return ROLE_ADMIN.equalsIgnoreCase(this.role);
    }
}
