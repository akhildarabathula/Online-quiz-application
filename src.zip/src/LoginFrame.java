import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * LoginFrame.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Modern SaaS Card Layout: Uses GridBagLayout on a #F8FAFC canvas to center a 420px
 *    rounded card (UITheme.RoundedPanel) with generous whitespace.
 * 2. Custom Graphics2D Controls: Uses ModernTextField, ModernPasswordField (with Indigo
 *    focus rings), and segmented Role Toggle buttons ("Student" / "Professor").
 * 3. Inheritance & Role Routing: Routes ADMIN accounts to AdminDashboardFrame and
 *    STUDENT accounts to QuizSelectionFrame.
 */
public class LoginFrame extends JFrame implements ActionListener {

    private boolean isAdminSelected = false; // Default role toggle: Student
    private UITheme.ModernButton studentToggleBtn;
    private UITheme.ModernButton professorToggleBtn;

    private UITheme.ModernTextField usernameField;
    private UITheme.ModernPasswordField passwordField;
    private UITheme.ModernButton signInButton;
    private UITheme.ModernButton createAccountButton;

    /**
     * Constructor: Builds the 2026 SaaS Login Screen (1100x750 canvas with centered 420px card).
     */
    public LoginFrame() {
        setTitle("QuizFlow — Assessment & Examination Platform");
        setSize(1100, 750);
        setMinimumSize(new Dimension(1100, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout()); // Centers the 420px login card on the #F8FAFC canvas
        getContentPane().setBackground(UITheme.BG_CANVAS);

        // Main Centered Card (420px wide)
        UITheme.RoundedPanel loginCard = new UITheme.RoundedPanel(
                new BorderLayout(), 16, UITheme.BG_CARD, UITheme.BORDER_CARD, 36, 36
        );
        loginCard.setPreferredSize(new Dimension(430, 540));

        JPanel contentStack = new JPanel();
        contentStack.setLayout(new BoxLayout(contentStack, BoxLayout.Y_AXIS));
        contentStack.setOpaque(false);

        // 1. Brand Pill + Hero Title + Subtitle
        JPanel brandRow = new JPanel(new BorderLayout());
        brandRow.setOpaque(false);
        UITheme.PillBadge brandBadge = new UITheme.PillBadge(
                "QUIZFLOW ASSESSMENT SUITE",
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );
        brandRow.add(brandBadge, BorderLayout.WEST);
        brandRow.setMaximumSize(new Dimension(360, 28));
        contentStack.add(brandRow);
        contentStack.add(Box.createRigidArea(new Dimension(0, 14)));

        JPanel headerTextPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        headerTextPanel.setOpaque(false);
        headerTextPanel.setMaximumSize(new Dimension(360, 62));

        JLabel heroTitle = new JLabel("Welcome back");
        heroTitle.setFont(UITheme.FONT_HERO);
        heroTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel subtitle = new JLabel("Sign in to your examination workspace");
        subtitle.setFont(UITheme.FONT_SUBTITLE);
        subtitle.setForeground(UITheme.TEXT_MUTED);

        headerTextPanel.add(heroTitle);
        headerTextPanel.add(subtitle);
        contentStack.add(headerTextPanel);
        contentStack.add(Box.createRigidArea(new Dimension(0, 22)));

        // 2. Segmented Role Toggle (Student / Professor)
        UITheme.RoundedPanel toggleTrack = new UITheme.RoundedPanel(
                new GridLayout(1, 2, 6, 0), 12, UITheme.BG_SUBTLE, UITheme.BORDER_CARD, 4, 4
        );
        toggleTrack.setMaximumSize(new Dimension(360, 44));
        toggleTrack.setPreferredSize(new Dimension(360, 44));

        studentToggleBtn = new UITheme.ModernButton(
                "Student Portal", UITheme.ACCENT_INDIGO, UITheme.ACCENT_INDIGO_HOVER, Color.WHITE, null
        );
        professorToggleBtn = new UITheme.ModernButton(
                "Professor (Admin)", UITheme.BG_SUBTLE, UITheme.BG_CARD, UITheme.TEXT_SECONDARY, null
        );

        studentToggleBtn.addActionListener(e -> setRoleSelection(false));
        professorToggleBtn.addActionListener(e -> setRoleSelection(true));

        toggleTrack.add(studentToggleBtn);
        toggleTrack.add(professorToggleBtn);
        contentStack.add(toggleTrack);
        contentStack.add(Box.createRigidArea(new Dimension(0, 20)));

        // 3. Username Input
        JPanel userLabelRow = new JPanel(new BorderLayout());
        userLabelRow.setOpaque(false);
        userLabelRow.setMaximumSize(new Dimension(360, 22));
        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(UITheme.FONT_BOLD);
        userLabel.setForeground(UITheme.TEXT_PRIMARY);
        userLabelRow.add(userLabel, BorderLayout.WEST);
        contentStack.add(userLabelRow);
        contentStack.add(Box.createRigidArea(new Dimension(0, 6)));

        usernameField = new UITheme.ModernTextField(20);
        usernameField.setMaximumSize(new Dimension(360, 44));
        usernameField.setPreferredSize(new Dimension(360, 44));
        contentStack.add(usernameField);
        contentStack.add(Box.createRigidArea(new Dimension(0, 16)));

        // 4. Password Input
        JPanel passLabelRow = new JPanel(new BorderLayout());
        passLabelRow.setOpaque(false);
        passLabelRow.setMaximumSize(new Dimension(360, 22));
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(UITheme.FONT_BOLD);
        passLabel.setForeground(UITheme.TEXT_PRIMARY);
        passLabelRow.add(passLabel, BorderLayout.WEST);
        contentStack.add(passLabelRow);
        contentStack.add(Box.createRigidArea(new Dimension(0, 6)));

        passwordField = new UITheme.ModernPasswordField(20);
        passwordField.setMaximumSize(new Dimension(360, 44));
        passwordField.setPreferredSize(new Dimension(360, 44));
        passwordField.addActionListener(this); // Pressing Enter submits login
        contentStack.add(passwordField);
        contentStack.add(Box.createRigidArea(new Dimension(0, 24)));

        // 5. Full-Width Sign In & Subtle Create Account Buttons
        JPanel actionsStack = new JPanel(new GridLayout(2, 1, 0, 10));
        actionsStack.setOpaque(false);
        actionsStack.setMaximumSize(new Dimension(360, 96));
        actionsStack.setPreferredSize(new Dimension(360, 96));

        signInButton = UITheme.createPrimaryButton("Sign In →");
        signInButton.addActionListener(this);

        createAccountButton = UITheme.createSecondaryButton("Create Student Account");
        createAccountButton.addActionListener(this);

        actionsStack.add(signInButton);
        actionsStack.add(createAccountButton);
        contentStack.add(actionsStack);
        contentStack.add(Box.createRigidArea(new Dimension(0, 18)));

        // 6. Demo Credentials Footer
        JLabel demoHint = new JLabel(
                "<html><center>Demo: <b>student1 / pass123</b> &nbsp;•&nbsp; <b>admin / admin123</b></center></html>",
                SwingConstants.CENTER
        );
        demoHint.setFont(UITheme.FONT_SMALL);
        demoHint.setForeground(UITheme.TEXT_MUTED);
        demoHint.setAlignmentX(CENTER_ALIGNMENT);
        contentStack.add(demoHint);

        loginCard.add(contentStack, BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(30, 30, 30, 30);
        add(loginCard, gbc);
    }

    /**
     * Updates the segmented Role Toggle visual state ("Student" vs "Professor").
     */
    private void setRoleSelection(boolean selectAdmin) {
        this.isAdminSelected = selectAdmin;
        if (selectAdmin) {
            professorToggleBtn.setColors(UITheme.ACCENT_INDIGO, UITheme.ACCENT_INDIGO_HOVER, Color.WHITE, null);
            studentToggleBtn.setColors(UITheme.BG_SUBTLE, UITheme.BG_CARD, UITheme.TEXT_SECONDARY, null);
        } else {
            studentToggleBtn.setColors(UITheme.ACCENT_INDIGO, UITheme.ACCENT_INDIGO_HOVER, Color.WHITE, null);
            professorToggleBtn.setColors(UITheme.BG_SUBTLE, UITheme.BG_CARD, UITheme.TEXT_SECONDARY, null);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both username and password.",
                    "Missing Credentials",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (username.contains(",") || password.contains(",")) {
            JOptionPane.showMessageDialog(this,
                    "Username and password cannot contain commas (,).",
                    "Invalid Input",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (e.getSource() == createAccountButton) {
            handleRegistration(username, password);
        } else {
            handleLogin(username, password);
        }
    }

    private void handleLogin(String username, String password) {
        User loggedInUser = FileManager.validateLogin(username, password);

        if (loggedInUser == null) {
            JOptionPane.showMessageDialog(this,
                    "Invalid username or password. Please verify your credentials.",
                    "Authentication Failed",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String expectedRole = isAdminSelected ? User.ROLE_ADMIN : User.ROLE_STUDENT;
        if (!loggedInUser.getRole().equalsIgnoreCase(expectedRole)) {
            JOptionPane.showMessageDialog(this,
                    "Account '" + username + "' belongs to role '" + loggedInUser.getRole()
                            + "'.\nPlease switch the Student / Professor toggle above!",
                    "Role Mismatch",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (loggedInUser.isAdmin()) {
            AdminDashboardFrame adminFrame = new AdminDashboardFrame(loggedInUser);
            adminFrame.setVisible(true);
            this.dispose();
        } else {
            QuizSelectionFrame selectionFrame = new QuizSelectionFrame(loggedInUser);
            selectionFrame.setVisible(true);
            this.dispose();
        }
    }

    private void handleRegistration(String username, String password) {
        if (isAdminSelected) {
            setRoleSelection(false);
        }

        User newUser = new User(username, password);
        boolean success = FileManager.registerUser(newUser);

        if (success) {
            JOptionPane.showMessageDialog(this,
                    "Student account '" + username + "' created!\nClick 'Sign In →' to enter the portal.",
                    "Account Created",
                    JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Username '" + username + "' is already registered. Please choose another.",
                    "Registration Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
