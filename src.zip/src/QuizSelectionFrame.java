import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 * QuizSelectionFrame.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Modern SaaS Subject Card Grid:
 *    Dynamically renders a RoundedPanel card for every subject configured in
 *    'quiz_config.txt' (loaded via FileManager.loadAllQuizConfigs()).
 * 2. Pill Badges & Lambda ActionListeners:
 *    Each subject card displays question count, seconds per question, positive/negative
 *    marking pills, and its own 'Start Assessment →' button.
 */
public class QuizSelectionFrame extends JFrame {

    private User currentUser;
    private ArrayList<QuizConfig> availableConfigs;

    /**
     * Constructor: Builds the 1100x750 Student Assessment Hub with a grid of Subject Cards.
     */
    public QuizSelectionFrame(User currentUser) {
        this.currentUser = currentUser;
        this.availableConfigs = FileManager.loadAllQuizConfigs();

        setTitle("QuizFlow — Student Assessment Workspace");
        setSize(1120, 760);
        setMinimumSize(new Dimension(1100, 750));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG_CANVAS);

        // 1. Top Navigation Bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.BG_CARD);
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CARD),
                BorderFactory.createEmptyBorder(16, 40, 16, 40)
        ));

        JPanel leftBrand = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        leftBrand.setOpaque(false);

        JLabel brandTitle = new JLabel("QuizFlow Assessments");
        brandTitle.setFont(UITheme.FONT_SECTION);
        brandTitle.setForeground(UITheme.TEXT_PRIMARY);

        // Calls getUsername() inherited from Person class!
        UITheme.PillBadge studentBadge = new UITheme.PillBadge(
                "CANDIDATE • " + currentUser.getUsername().toUpperCase(),
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );

        leftBrand.add(brandTitle);
        leftBrand.add(studentBadge);

        UITheme.ModernButton logoutButton = UITheme.createSecondaryButton("Sign Out");
        logoutButton.addActionListener(e -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
            this.dispose();
        });

        topBar.add(leftBrand, BorderLayout.WEST);
        topBar.add(logoutButton, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // 2. Main Workspace Canvas with 36px-40px Outer Padding
        JPanel workspace = new JPanel(new BorderLayout(0, 24));
        workspace.setBackground(UITheme.BG_CANVAS);
        workspace.setBorder(BorderFactory.createEmptyBorder(32, 40, 36, 40));

        // Hero Section Header + Proctoring Notice Banner
        JPanel heroHeader = new JPanel(new BorderLayout(0, 14));
        heroHeader.setOpaque(false);

        JPanel titleStack = new JPanel(new GridLayout(2, 1, 0, 4));
        titleStack.setOpaque(false);

        JLabel heroTitle = new JLabel("Available Assessments");
        heroTitle.setFont(UITheme.FONT_HERO);
        heroTitle.setForeground(UITheme.TEXT_PRIMARY);

        JLabel heroSub = new JLabel("Select a subject module below to begin your timed, proctored examination.");
        heroSub.setFont(UITheme.FONT_BODY);
        heroSub.setForeground(UITheme.TEXT_MUTED);

        titleStack.add(heroTitle);
        titleStack.add(heroSub);
        heroHeader.add(titleStack, BorderLayout.NORTH);

        // Subtle Anti-Cheat Info Banner
        UITheme.RoundedPanel proctorBanner = new UITheme.RoundedPanel(
                new BorderLayout(12, 0), 12, UITheme.DANGER_SOFT_BG, UITheme.DANGER_BORDER, 12, 18
        );
        JLabel proctorText = new JLabel(
                "⚠ Active Focus Proctoring: Once an assessment starts, switching windows or pressing Alt+Tab will immediately auto-submit your attempt."
        );
        proctorText.setFont(UITheme.FONT_BOLD);
        proctorText.setForeground(UITheme.DANGER_HOVER);
        proctorBanner.add(proctorText, BorderLayout.WEST);
        heroHeader.add(proctorBanner, BorderLayout.SOUTH);

        workspace.add(heroHeader, BorderLayout.NORTH);

        // 3. Grid of Modern Subject Cards
        int rows = Math.max(2, (availableConfigs.size() + 1) / 2);
        JPanel cardsGrid = new JPanel(new GridLayout(rows, 2, 24, 24));
        cardsGrid.setBackground(UITheme.BG_CANVAS);

        for (QuizConfig cfg : availableConfigs) {
            cardsGrid.add(createSubjectCard(cfg));
        }

        // Fill empty slot if only 1 card exists so cards keep nice proportions
        if (availableConfigs.size() == 1) {
            JPanel placeholder = new JPanel();
            placeholder.setOpaque(false);
            cardsGrid.add(placeholder);
        }

        JPanel gridWrapper = new JPanel(new BorderLayout());
        gridWrapper.setBackground(UITheme.BG_CANVAS);
        gridWrapper.add(cardsGrid, BorderLayout.NORTH);

        JScrollPane scrollPane = new JScrollPane(gridWrapper);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(UITheme.BG_CANVAS);
        scrollPane.getVerticalScrollBar().setUnitIncrement(18);

        workspace.add(scrollPane, BorderLayout.CENTER);
        add(workspace, BorderLayout.CENTER);
    }

    /**
     * Builds an individual SaaS Subject Card displaying badges, rules, and 'Start Assessment →' button.
     */
    private UITheme.RoundedPanel createSubjectCard(QuizConfig cfg) {
        UITheme.RoundedPanel card = new UITheme.RoundedPanel(
                new BorderLayout(0, 18), 16, UITheme.BG_CARD, UITheme.BORDER_CARD, 26, 28
        );

        // Top: Subject Title + Max Score Badge
        JPanel topRow = new JPanel(new BorderLayout(12, 0));
        topRow.setOpaque(false);

        JLabel subjectTitle = new JLabel(cfg.getSubject());
        subjectTitle.setFont(UITheme.FONT_TITLE);
        subjectTitle.setForeground(UITheme.TEXT_PRIMARY);

        double maxMarks = cfg.getNumQuestionsToPick() * cfg.getMarksPerQuestion();
        UITheme.PillBadge maxScoreBadge = new UITheme.PillBadge(
                "MAX SCORE: " + maxMarks + " PTS",
                UITheme.ACCENT_INDIGO_SOFT,
                UITheme.ACCENT_INDIGO,
                UITheme.ACCENT_INDIGO_BDR
        );

        topRow.add(subjectTitle, BorderLayout.WEST);
        topRow.add(maxScoreBadge, BorderLayout.EAST);
        card.add(topRow, BorderLayout.NORTH);

        // Middle: Metric Badges & Marking Breakdown
        JPanel middleStack = new JPanel();
        middleStack.setLayout(new BoxLayout(middleStack, BoxLayout.Y_AXIS));
        middleStack.setOpaque(false);

        JLabel descLabel = new JLabel(
                "Randomized multiple-choice evaluation with automatic per-question countdown timer."
        );
        descLabel.setFont(UITheme.FONT_SUBTITLE);
        descLabel.setForeground(UITheme.TEXT_MUTED);
        descLabel.setAlignmentX(LEFT_ALIGNMENT);
        middleStack.add(descLabel);
        middleStack.add(Box.createRigidArea(new Dimension(0, 14)));

        // Pill Badges Row
        JPanel badgesFlow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        badgesFlow.setOpaque(false);
        badgesFlow.setAlignmentX(LEFT_ALIGNMENT);

        badgesFlow.add(new UITheme.PillBadge(
                cfg.getNumQuestionsToPick() + " Questions",
                UITheme.BG_SUBTLE,
                UITheme.TEXT_PRIMARY,
                UITheme.BORDER_CARD
        ));

        badgesFlow.add(new UITheme.PillBadge(
                "⏱ " + cfg.getTimePerQuestionSeconds() + "s / Question",
                UITheme.WARNING_SOFT_BG,
                new Color(180, 83, 9),
                null
        ));

        badgesFlow.add(new UITheme.PillBadge(
                "+" + cfg.getMarksPerQuestion() + " Correct",
                UITheme.SUCCESS_SOFT_BG,
                UITheme.SUCCESS_HOVER,
                UITheme.SUCCESS_BORDER
        ));

        if (cfg.getNegativeMarks() > 0) {
            badgesFlow.add(new UITheme.PillBadge(
                    "-" + cfg.getNegativeMarks() + " Negative",
                    UITheme.DANGER_SOFT_BG,
                    UITheme.DANGER_HOVER,
                    UITheme.DANGER_BORDER
            ));
        } else {
            badgesFlow.add(new UITheme.PillBadge(
                    "No Negative Marking",
                    UITheme.BG_SUBTLE,
                    UITheme.TEXT_MUTED,
                    UITheme.BORDER_CARD
            ));
        }

        middleStack.add(badgesFlow);
        card.add(middleStack, BorderLayout.CENTER);

        // Bottom: Bank Status + Start Assessment Button
        JPanel bottomRow = new JPanel(new BorderLayout());
        bottomRow.setOpaque(false);
        bottomRow.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, UITheme.BG_SUBTLE),
                BorderFactory.createEmptyBorder(14, 0, 0, 0)
        ));

        int totalInBank = FileManager.loadQuestionsBySubject(cfg.getSubject()).size();
        JLabel bankInfo = new JLabel("Question Pool: " + totalInBank + " verified MCQs");
        bankInfo.setFont(UITheme.FONT_SMALL);
        bankInfo.setForeground(UITheme.TEXT_MUTED);

        UITheme.ModernButton startBtn = UITheme.createPrimaryButton("Start Assessment →");
        startBtn.addActionListener(e -> launchAssessment(cfg));

        bottomRow.add(bankInfo, BorderLayout.WEST);
        bottomRow.add(startBtn, BorderLayout.EAST);
        card.add(bottomRow, BorderLayout.SOUTH);

        return card;
    }

    /**
     * Loads a shuffled subset of questions via FileManager and opens QuizFrame.
     */
    private void launchAssessment(QuizConfig selectedConfig) {
        ArrayList<Question> randomQuestions = FileManager.getQuestionsForQuiz(
                selectedConfig.getSubject(),
                selectedConfig.getNumQuestionsToPick()
        );

        if (randomQuestions.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No questions found in the bank for '" + selectedConfig.getSubject()
                            + "'.\nPlease ask the Professor (Admin) to add questions first.",
                    "Empty Question Bank",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        QuizFrame quizFrame = new QuizFrame(currentUser, selectedConfig, randomQuestions);
        quizFrame.setVisible(true);
        this.dispose();
    }
}
