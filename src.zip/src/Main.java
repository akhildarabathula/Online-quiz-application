import java.awt.Desktop;
import java.net.URI;

/**
 * Main.java
 * 
 * VIVA CONCEPTS COVERED:
 * 1. Application Entry Point ('public static void main(String[] args)'):
 *    Initializes the .txt data files via FileManager and starts the built-in
 *    Java HTTP Web Server (QuizWebServer) on port 8080.
 * 2. Cross-Device Accessibility:
 *    Runs on http://localhost:8080 (Laptop) and http://<PC-IP>:8080 (Mobile Phones
 *    on the same Wi-Fi or Hotspot). Also supports '--swing' argument if you ever
 *    want to demo the legacy desktop Swing GUI alongside the Web App!
 */
public class Main {

    public static void main(String[] args) {
        // Step 1: Ensure users.txt, quiz_config.txt, questions.txt, and results.txt exist
        FileManager.initializeDataFiles();

        // Optional flag: pass "--swing" to launch the desktop Swing window
        if (args.length > 0 && "--swing".equalsIgnoreCase(args[0])) {
            System.setProperty("awt.useSystemAAFontSettings", "on");
            System.setProperty("swing.aatext", "true");
            UITheme.applyGlobalTheme();
            javax.swing.SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            });
            return;
        }

        // Step 2: Start the built-in Java Web Server on 0.0.0.0:8080
        int port = 8080;
        try {
            QuizWebServer webServer = new QuizWebServer(port);
            webServer.start();

            // Automatically open http://localhost:8080 in the default browser if supported
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                try {
                    Desktop.getDesktop().browse(new URI("http://localhost:" + port));
                } catch (Exception ignored) {
                    // Browser can always be opened manually via the printed URL
                }
            }
        } catch (Exception e) {
            System.out.println("Failed to start QuizWebServer on port " + port + ": " + e.getMessage());
            e.printStackTrace();
        }
    }
}
