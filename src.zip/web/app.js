/**
 * app.js
 * 
 * Client-Side Controller for QuizFlow Web Application
 * Communicates with Java's built-in HttpServer (QuizWebServer.java)
 * 
 * KEY FEATURES DEMONSTRATED:
 * 1. Role-Based Authentication (Student vs Professor/Admin)
 * 2. Exam Timing Window Enforcement (Live Now vs Scheduled / Closed)
 * 3. Individual & Bulk "Unlock All Students" Re-Access Control
 * 4. Strict Anti-Cheating (visibilitychange + window blur + copy/paste/right-click lock)
 * 5. Per-Question Countdown Timer with animated progress bar
 * 6. GATE/JEE-style Candidate Response Sheet
 */

let currentUser = {
  username: "",
  role: "STUDENT"
};

let selectedLoginRole = "STUDENT";

// Active Quiz State
let activeQuiz = {
  inProgress: false,
  sessionId: "",
  subject: "",
  timePerQuestionSeconds: 15,
  marksPerQuestion: 4.0,
  negativeMarks: 1.0,
  questions: [],
  userAnswers: [],
  currentIndex: 0,
  remainingSeconds: 15,
  timerInterval: null
};

// Cached Admin Configs for Preset Dropdown
let cachedAdminConfigs = [];

// =========================================================================
// 1. VIEW NAVIGATION & TOAST HELPERS
// =========================================================================

function showView(viewId) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  const target = document.getElementById(viewId);
  if (target) {
    target.classList.add("active");
  }
  window.scrollTo(0, 0);
}

function showToast(message) {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => {
    toast.remove();
  }, 4000);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// =========================================================================
// 2. LOGIN & REGISTRATION
// =========================================================================

function setLoginRole(role) {
  selectedLoginRole = role;
  document.getElementById("role-btn-student").classList.toggle("active", role === "STUDENT");
  document.getElementById("role-btn-admin").classList.toggle("active", role === "ADMIN");
  document.getElementById("register-btn").style.display = (role === "STUDENT") ? "inline-flex" : "none";
}

function fillDemo(username, password, role) {
  setLoginRole(role);
  document.getElementById("login-username").value = username;
  document.getElementById("login-password").value = password;
  showToast(`Filled ${role} demo credentials (${username})`);
}

async function handleLoginSubmit(event) {
  event.preventDefault();
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value.trim();

  try {
    const res = await fetch("/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password, role: selectedLoginRole })
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Login failed"));
      return;
    }

    currentUser.username = data.username;
    currentUser.role = data.role;

    if (currentUser.role === "ADMIN") {
      document.getElementById("admin-user-pill").textContent = "PROFESSOR • " + currentUser.username.toUpperCase();
      showView("view-admin");
      loadAdminData();
    } else {
      document.getElementById("student-badge").textContent = "CANDIDATE • " + currentUser.username.toUpperCase();
      showView("view-student");
      loadStudentQuizzes();
    }
  } catch (err) {
    showToast("⚠️ Server connection error: " + err.message);
  }
}

async function handleRegister() {
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value.trim();

  if (!username || !password) {
    showToast("⚠️ Enter a username and password to register a new Student account.");
    return;
  }

  try {
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Registration failed"));
      return;
    }

    showToast("✅ Student account '" + data.username + "' created! Signing you in...");
    setLoginRole("STUDENT");
    currentUser.username = data.username;
    currentUser.role = "STUDENT";
    document.getElementById("student-badge").textContent = "CANDIDATE • " + currentUser.username.toUpperCase();
    showView("view-student");
    loadStudentQuizzes();
  } catch (err) {
    showToast("⚠️ Registration error: " + err.message);
  }
}

function logout() {
  stopActiveQuizTimer();
  activeQuiz.inProgress = false;
  currentUser = { username: "", role: "STUDENT" };
  document.getElementById("login-password").value = "";
  showView("view-login");
}

// =========================================================================
// 3. STUDENT ASSESSMENT HUB (EXAM TIMING WINDOW + LOCK CHECK)
// =========================================================================

async function loadStudentQuizzes() {
  const grid = document.getElementById("student-quiz-grid");
  grid.innerHTML = `<div class="glass-card"><p>Loading available assessments...</p></div>`;

  try {
    const res = await fetch(`/api/quizzes?username=${encodeURIComponent(currentUser.username)}`);
    const data = await res.json();
    const quizzes = data.quizzes || [];

    if (quizzes.length === 0) {
      grid.innerHTML = `<div class="glass-card"><p>No subjects configured yet. Ask your Professor to configure a quiz.</p></div>`;
      return;
    }

    grid.innerHTML = quizzes.map(q => {
      const maxMarks = (q.numQuestionsToPick * q.marksPerQuestion).toFixed(1);
      const isLocked = q.locked === true;
      const isAvailableNow = q.availableNow === true;
      const timeWindowLabel = q.formattedTimeWindow || "All Day";

      // Schedule & Live Timing Badge
      let schedulePillHtml = "";
      if (isAvailableNow) {
        schedulePillHtml = `
          <span class="pill pill-emerald">
            ● Live Now &bull; ${escapeHtml(timeWindowLabel)}
          </span>
        `;
      } else if (!q.examActive) {
        schedulePillHtml = `
          <span class="pill pill-crimson">
            ⏸ Closed by Professor &bull; Scheduled: ${escapeHtml(timeWindowLabel)}
          </span>
        `;
      } else {
        schedulePillHtml = `
          <span class="pill pill-amber">
            ⏳ Scheduled: ${escapeHtml(timeWindowLabel)}
          </span>
        `;
      }

      // Lock or Closed Alert Box
      let statusAlertBox = "";
      if (isLocked) {
        statusAlertBox = `
          <div class="locked-alert-box">
            <div><strong>🔒 Attempt Locked — Contact Professor to Unlock</strong></div>
            <div style="margin-top:4px;">Last Score: <strong>${escapeHtml(q.lastScore)} / ${escapeHtml(q.lastMaxScore)}</strong> &bull; Status: <strong>${escapeHtml(q.lastStatus)}</strong></div>
          </div>
        `;
      } else if (!isAvailableNow) {
        statusAlertBox = `
          <div class="closed-alert-box">
            <strong>⏳ Closed — Available only during Exam Timings (${escapeHtml(timeWindowLabel)})</strong>
          </div>
        `;
      }

      // Action Button
      let actionBtn = "";
      if (isLocked) {
        actionBtn = `
          <button type="button" class="btn btn-danger-soft btn-sm" disabled>
            🔒 Attempt Locked
          </button>
        `;
      } else if (!isAvailableNow) {
        actionBtn = `
          <button type="button" class="btn btn-secondary btn-sm" disabled>
            ⏳ Outside Exam Window
          </button>
        `;
      } else {
        actionBtn = `
          <button type="button" class="btn btn-primary btn-sm" onclick="startQuiz('${escapeHtml(q.subject)}')">
            Start Assessment &rarr;
          </button>
        `;
      }

      return `
        <div class="glass-card quiz-card ${(isLocked || !isAvailableNow) ? 'locked-card' : ''}">
          <div>
            <div class="quiz-card-top">
              <h3 class="quiz-card-title">${escapeHtml(q.subject)}</h3>
              <span class="pill ${isLocked ? 'pill-crimson' : 'pill-indigo'}">
                ${isLocked ? '🔒 LOCKED' : 'MAX ' + maxMarks + ' PTS'}
              </span>
            </div>

            <div class="quiz-schedule-row">
              ${schedulePillHtml}
            </div>

            <div class="quiz-meta-pills">
              <span class="pill pill-slate">📋 ${q.numQuestionsToPick} Questions</span>
              <span class="pill pill-amber">⏱ ${q.timePerQuestionSeconds}s / Question</span>
              <span class="pill pill-emerald">+${q.marksPerQuestion} Correct</span>
              <span class="pill ${q.negativeMarks > 0 ? 'pill-crimson' : 'pill-slate'}">
                ${q.negativeMarks > 0 ? '-' + q.negativeMarks + ' Negative' : 'No Negative Marks'}
              </span>
            </div>

            ${statusAlertBox}
          </div>

          <div class="quiz-card-footer">
            <span style="font-size:12px; color:var(--text-muted);">Pool: ${q.bankCount} verified MCQs</span>
            ${actionBtn}
          </div>
        </div>
      `;
    }).join("");
  } catch (err) {
    grid.innerHTML = `<div class="glass-card"><p>Error loading quizzes: ${escapeHtml(err.message)}</p></div>`;
  }
}

// =========================================================================
// 4. START QUIZ, PER-QUESTION TIMER & STRICT ANTI-CHEAT
// =========================================================================

async function startQuiz(subject) {
  try {
    const res = await fetch("/api/quiz/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: currentUser.username, subject })
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      showToast("🔒 " + (data.error || "Cannot start assessment."));
      loadStudentQuizzes();
      return;
    }

    activeQuiz.inProgress = true;
    activeQuiz.sessionId = data.sessionId;
    activeQuiz.subject = data.subject;
    activeQuiz.timePerQuestionSeconds = data.timePerQuestionSeconds;
    activeQuiz.marksPerQuestion = data.marksPerQuestion;
    activeQuiz.negativeMarks = data.negativeMarks;
    activeQuiz.questions = data.questions || [];
    activeQuiz.userAnswers = new Array(activeQuiz.questions.length).fill(-1);
    activeQuiz.currentIndex = 0;

    document.getElementById("active-quiz-subject").textContent = activeQuiz.subject;
    document.getElementById("active-marking-badge").textContent =
      `+${activeQuiz.marksPerQuestion} Correct • -${activeQuiz.negativeMarks} Wrong`;

    showView("view-quiz");
    renderCurrentQuestion();
  } catch (err) {
    showToast("⚠️ Error starting quiz: " + err.message);
  }
}

function renderCurrentQuestion() {
  const idx = activeQuiz.currentIndex;
  const total = activeQuiz.questions.length;
  const q = activeQuiz.questions[idx];

  document.getElementById("active-quiz-counter").textContent = `Question ${idx + 1} of ${total}`;
  document.getElementById("active-question-badge").textContent = `QUESTION ${idx + 1}`;
  document.getElementById("active-question-text").textContent = `Q${idx + 1}. ${q.questionText}`;

  const letters = ["A", "B", "C", "D"];
  const optionsContainer = document.getElementById("active-options-list");
  optionsContainer.innerHTML = q.options.map((optText, optIndex) => {
    const isSelected = activeQuiz.userAnswers[idx] === optIndex;
    return `
      <div class="option-card ${isSelected ? 'selected' : ''}" onclick="selectOption(${optIndex})">
        <div class="option-letter">${letters[optIndex]}</div>
        <div class="option-text">${escapeHtml(optText)}</div>
      </div>
    `;
  }).join("");

  document.getElementById("btn-prev-q").disabled = (idx === 0);
  document.getElementById("btn-next-q").disabled = (idx === total - 1);

  startPerQuestionTimer();
}

function selectOption(optIndex) {
  if (!activeQuiz.inProgress) return;
  activeQuiz.userAnswers[activeQuiz.currentIndex] = optIndex;
  const cards = document.querySelectorAll("#active-options-list .option-card");
  cards.forEach((card, idx) => {
    card.classList.toggle("selected", idx === optIndex);
  });
}

function clearCurrentSelection() {
  if (!activeQuiz.inProgress) return;
  activeQuiz.userAnswers[activeQuiz.currentIndex] = -1;
  document.querySelectorAll("#active-options-list .option-card").forEach(card => {
    card.classList.remove("selected");
  });
}

function navigateQuestion(direction) {
  if (!activeQuiz.inProgress) return;
  const nextIdx = activeQuiz.currentIndex + direction;
  if (nextIdx >= 0 && nextIdx < activeQuiz.questions.length) {
    activeQuiz.currentIndex = nextIdx;
    renderCurrentQuestion();
  }
}

function startPerQuestionTimer() {
  stopActiveQuizTimer();
  activeQuiz.remainingSeconds = activeQuiz.timePerQuestionSeconds;
  updateTimerUI();

  activeQuiz.timerInterval = setInterval(() => {
    if (!activeQuiz.inProgress) {
      stopActiveQuizTimer();
      return;
    }

    activeQuiz.remainingSeconds--;
    updateTimerUI();

    if (activeQuiz.remainingSeconds <= 0) {
      stopActiveQuizTimer();
      if (activeQuiz.currentIndex < activeQuiz.questions.length - 1) {
        activeQuiz.currentIndex++;
        renderCurrentQuestion();
      } else {
        submitQuiz("TIME_UP");
      }
    }
  }, 1000);
}

function stopActiveQuizTimer() {
  if (activeQuiz.timerInterval) {
    clearInterval(activeQuiz.timerInterval);
    activeQuiz.timerInterval = null;
  }
}

function updateTimerUI() {
  const sec = Math.max(0, activeQuiz.remainingSeconds);
  const maxSec = activeQuiz.timePerQuestionSeconds;
  const pct = Math.max(0, Math.min(100, (sec / maxSec) * 100));

  const pill = document.getElementById("active-quiz-timer-pill");
  const text = document.getElementById("active-quiz-timer-text");
  const fill = document.getElementById("timer-progress-fill");

  text.textContent = `${sec}s`;
  fill.style.width = `${pct}%`;

  const isLow = sec <= 5;
  pill.classList.toggle("danger", isLow);
  fill.classList.toggle("danger", isLow);
}

function confirmAndSubmitQuiz() {
  if (!activeQuiz.inProgress) return;
  submitQuiz("COMPLETED");
}

async function submitQuiz(submissionStatus) {
  if (!activeQuiz.inProgress) return;
  activeQuiz.inProgress = false;
  stopActiveQuizTimer();

  const answersCsv = activeQuiz.userAnswers.join(",");

  try {
    const res = await fetch("/api/quiz/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        sessionId: activeQuiz.sessionId,
        status: submissionStatus,
        answers: answersCsv
      })
    });
    const report = await res.json();

    if (!res.ok || report.error) {
      showToast("⚠️ " + (report.error || "Error submitting quiz"));
      showView("view-student");
      loadStudentQuizzes();
      return;
    }

    if (submissionStatus.includes("TAB SWITCH")) {
      showToast("🚨 PROCTORING ALERT: Tab/App switch detected! Exam auto-submitted & locked.");
    } else if (submissionStatus === "TIME_UP") {
      showToast("⏱ Time expired! Your exam has been automatically submitted.");
    } else {
      showToast("✅ Assessment submitted & locked!");
    }

    renderCandidateResponseSheet(report);
    showView("view-result");
  } catch (err) {
    showToast("⚠️ Submission failed: " + err.message);
  }
}

// =========================================================================
// STRICT ANTI-CHEATING LISTENERS (DESKTOP + MOBILE PHONE)
// =========================================================================

document.addEventListener("visibilitychange", () => {
  if (activeQuiz.inProgress && document.hidden) {
    submitQuiz("AUTO-SUBMITTED (TAB SWITCH)");
  }
});

window.addEventListener("blur", () => {
  if (activeQuiz.inProgress) {
    submitQuiz("AUTO-SUBMITTED (TAB SWITCH)");
  }
});

["contextmenu", "copy", "cut", "paste"].forEach(evtName => {
  document.addEventListener(evtName, e => {
    if (activeQuiz.inProgress) {
      e.preventDefault();
      showToast("🛡️ Action disabled during active proctored exam.");
    }
  });
});

// =========================================================================
// 5. CANDIDATE RESPONSE SHEET RENDERER
// =========================================================================

function renderCandidateResponseSheet(report) {
  const isViolation = String(report.status).includes("TAB SWITCH");
  const statusPill = document.getElementById("result-status-pill");
  statusPill.className = "pill " + (isViolation ? "pill-crimson" : "pill-emerald");
  statusPill.textContent = isViolation ? "⚠ " + report.status : "✓ " + report.status;

  const hero = document.getElementById("result-hero-card");
  hero.innerHTML = `
    <div class="hero-stat-box">
      <div class="hero-stat-label">FINAL SCORE</div>
      <div class="hero-stat-value" style="color:var(--indigo-primary);">${report.score} / ${report.maxScore}</div>
      <div class="hero-stat-sub">Candidate: ${escapeHtml(report.username)}</div>
    </div>
    <div class="hero-stat-box">
      <div class="hero-stat-label">SUBJECT</div>
      <div class="hero-stat-value" style="font-size:18px;">${escapeHtml(report.subject)}</div>
      <div class="hero-stat-sub">+${report.marksPerQuestion} / -${report.negativeMarks} scheme</div>
    </div>
    <div class="hero-stat-box">
      <div class="hero-stat-label">CORRECT ANSWERS</div>
      <div class="hero-stat-value" style="color:var(--emerald-primary);">${report.correctCount}</div>
      <div class="hero-stat-sub">+${(report.correctCount * report.marksPerQuestion).toFixed(2)} marks</div>
    </div>
    <div class="hero-stat-box">
      <div class="hero-stat-label">WRONG ANSWERS</div>
      <div class="hero-stat-value" style="color:var(--crimson-primary);">${report.wrongCount}</div>
      <div class="hero-stat-sub">-${(report.wrongCount * report.negativeMarks).toFixed(2)} penalty</div>
    </div>
    <div class="hero-stat-box">
      <div class="hero-stat-label">UNANSWERED</div>
      <div class="hero-stat-value" style="color:var(--text-muted);">${report.unansweredCount}</div>
      <div class="hero-stat-sub">0.0 marks</div>
    </div>
  `;

  const letters = ["A", "B", "C", "D"];
  const listContainer = document.getElementById("response-sheet-list");
  const items = report.responseSheet || [];

  listContainer.innerHTML = items.map(item => {
    const chosen = item.selectedIndex;
    const correctIdx = item.correctIndex;
    const isUnanswered = chosen < 0 || chosen > 3;
    const isCorrect = chosen === correctIdx;

    let badgeClass = "pill-slate";
    let badgeText = "0.0 Marks • Unanswered";
    if (!isUnanswered && isCorrect) {
      badgeClass = "pill-emerald";
      badgeText = `+${report.marksPerQuestion} Marks • Correct`;
    } else if (!isUnanswered && !isCorrect) {
      badgeClass = "pill-crimson";
      badgeText = `-${report.negativeMarks} Marks • Incorrect`;
    }

    const optionsHtml = item.options.map((optText, i) => {
      let rowClass = "response-opt-row";
      let rightTag = "";

      if (i === chosen && isCorrect) {
        rowClass += " user-correct";
        rightTag = `<span>[Your Answer &#10003;]</span>`;
      } else if (i === chosen && !isCorrect) {
        rowClass += " user-wrong";
        rightTag = `<span>[Your Answer &#10007;]</span>`;
      }

      return `
        <div class="${rowClass}">
          <span><strong>Option ${letters[i]}:</strong> &nbsp;${escapeHtml(optText)}</span>
          ${rightTag}
        </div>
      `;
    }).join("");

    return `
      <div class="glass-card response-q-card">
        <div class="response-q-header">
          <div class="response-q-title">Q${item.qNumber}. ${escapeHtml(item.questionText)}</div>
          <span class="pill ${badgeClass}">${badgeText}</span>
        </div>

        <div class="response-options-grid">
          ${optionsHtml}
        </div>

        <div class="response-correct-footer">
          &#10003; Correct Answer: Option ${letters[correctIdx]} &mdash; ${escapeHtml(item.options[correctIdx])}
        </div>
      </div>
    `;
  }).join("");
}

function backToStudentHub() {
  showView("view-student");
  loadStudentQuizzes();
}

// =========================================================================
// 6. PROFESSOR / ADMIN DASHBOARD, EXAM TIMINGS & BULK UNLOCK CONTROLS
// =========================================================================

function switchAdminTab(tabName) {
  ["config", "questions", "results"].forEach(t => {
    document.getElementById(`tab-btn-${t}`).classList.toggle("active", t === tabName);
    document.getElementById(`admin-tab-${t}`).classList.toggle("active", t === tabName);
  });
  loadAdminData();
}

function setAllDayWindow() {
  document.getElementById("cfg-start-time").value = "00:00";
  document.getElementById("cfg-end-time").value = "23:59";
  document.getElementById("cfg-active").value = "true";
  showToast("⏱ Set timing window to 24-Hour All-Day Open (00:00 - 23:59). Click Save to apply.");
}

async function loadAdminData() {
  try {
    const res = await fetch("/api/admin/data");
    const data = await res.json();

    cachedAdminConfigs = data.configs || [];
    const results = data.results || [];

    // Populate Config Preset, Question Bank Subject, and Bulk Unlock Subject Dropdowns
    const presetSelect = document.getElementById("cfg-preset");
    const qSubjectSelect = document.getElementById("q-subject");
    const bulkUnlockSelect = document.getElementById("bulk-unlock-subject");

    presetSelect.innerHTML = `<option value="">+ Create New Subject</option>` +
      cachedAdminConfigs.map((c, idx) => `<option value="${idx}">${escapeHtml(c.subject)}</option>`).join("");

    const subjectOptionsHtml = cachedAdminConfigs
      .map(c => `<option value="${escapeHtml(c.subject)}">${escapeHtml(c.subject)}</option>`)
      .join("");

    qSubjectSelect.innerHTML = subjectOptionsHtml;
    bulkUnlockSelect.innerHTML = subjectOptionsHtml;

    // Render Active Configs & Exam Timings Table
    const cfgTbody = document.getElementById("admin-configs-tbody");
    cfgTbody.innerHTML = cachedAdminConfigs.map(c => {
      let statePill = "";
      if (c.availableNow) {
        statePill = `<span class="pill pill-emerald">🟢 Live Open</span>`;
      } else if (!c.examActive) {
        statePill = `<span class="pill pill-crimson">🔴 Closed / Paused</span>`;
      } else {
        statePill = `<span class="pill pill-amber">⏳ Scheduled Window</span>`;
      }

      const toggleBtn = c.examActive
        ? `<button type="button" class="btn btn-danger-soft btn-sm" onclick="quickToggleExam('${escapeHtml(c.subject)}', false, '${escapeHtml(c.examTimeWindow)}')">
             ⏸ Pause / Close
           </button>`
        : `<button type="button" class="btn btn-success btn-sm" onclick="quickToggleExam('${escapeHtml(c.subject)}', true, '${escapeHtml(c.examTimeWindow)}')">
             ▶ Open Exam Now
           </button>`;

      return `
        <tr>
          <td><strong>${escapeHtml(c.subject)}</strong></td>
          <td>${c.numQuestionsToPick} Qs &bull; ${c.timePerQuestionSeconds}s/Q</td>
          <td>
            <span class="pill pill-emerald">+${c.marksPerQuestion}</span>
            <span class="pill ${c.negativeMarks > 0 ? 'pill-crimson' : 'pill-slate'}">-${c.negativeMarks}</span>
          </td>
          <td><strong>${escapeHtml(c.formattedTimeWindow)}</strong></td>
          <td>${statePill}</td>
          <td>${c.bankCount} MCQs</td>
          <td>${toggleBtn}</td>
        </tr>
      `;
    }).join("");

    // Render Student Results & Unlock Control Table
    const resTbody = document.getElementById("admin-results-tbody");
    if (results.length === 0) {
      resTbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color:var(--text-muted);">No student attempts recorded yet.</td></tr>`;
    } else {
      resTbody.innerHTML = results.map(r => {
        const isTabSwitch = String(r.status).includes("TAB SWITCH");
        const isLocked = r.locked === true;

        return `
          <tr>
            <td><strong>${escapeHtml(r.username)}</strong></td>
            <td>${escapeHtml(r.subject)}</td>
            <td><strong>${escapeHtml(r.score)} / ${escapeHtml(r.maxScore)}</strong></td>
            <td>
              <span class="pill ${isTabSwitch ? 'pill-crimson' : 'pill-emerald'}">
                ${escapeHtml(r.status)}
              </span>
            </td>
            <td>
              <span class="pill ${isLocked ? 'pill-crimson' : 'pill-slate'}">
                ${isLocked ? '🔒 Locked' : '🔓 Unlocked'}
              </span>
            </td>
            <td>
              ${isLocked
                ? `<button type="button" class="btn btn-primary btn-sm" onclick="unlockStudentAttempt('${escapeHtml(r.username)}', '${escapeHtml(r.subject)}')">
                     🔓 Unlock Rewrite
                   </button>`
                : `<span style="font-size:12px; color:var(--text-muted);">Rewrite Permitted</span>`
              }
            </td>
          </tr>
        `;
      }).join("");
    }
  } catch (err) {
    showToast("⚠️ Failed to load admin data: " + err.message);
  }
}

function onSelectConfigPreset() {
  const idx = document.getElementById("cfg-preset").value;
  if (idx === "") {
    document.getElementById("cfg-subject").value = "";
    document.getElementById("cfg-num-q").value = "5";
    document.getElementById("cfg-time").value = "15";
    document.getElementById("cfg-marks").value = "4.0";
    document.getElementById("cfg-neg").value = "1.0";
    document.getElementById("cfg-start-time").value = "00:00";
    document.getElementById("cfg-end-time").value = "23:59";
    document.getElementById("cfg-active").value = "true";
    return;
  }

  const cfg = cachedAdminConfigs[Number(idx)];
  if (cfg) {
    document.getElementById("cfg-subject").value = cfg.subject;
    document.getElementById("cfg-num-q").value = cfg.numQuestionsToPick;
    document.getElementById("cfg-time").value = cfg.timePerQuestionSeconds;
    document.getElementById("cfg-marks").value = cfg.marksPerQuestion;
    document.getElementById("cfg-neg").value = cfg.negativeMarks;
    document.getElementById("cfg-start-time").value = cfg.startTime || "00:00";
    document.getElementById("cfg-end-time").value = cfg.endTime || "23:59";
    document.getElementById("cfg-active").value = cfg.examActive ? "true" : "false";
  }
}

async function handleSaveQuizConfig(event) {
  event.preventDefault();
  const startTime = document.getElementById("cfg-start-time").value.trim() || "00:00";
  const endTime = document.getElementById("cfg-end-time").value.trim() || "23:59";

  const payload = {
    subject: document.getElementById("cfg-subject").value.trim(),
    numQuestionsToPick: document.getElementById("cfg-num-q").value.trim(),
    timePerQuestionSeconds: document.getElementById("cfg-time").value.trim(),
    marksPerQuestion: document.getElementById("cfg-marks").value.trim(),
    negativeMarks: document.getElementById("cfg-neg").value.trim(),
    examActive: document.getElementById("cfg-active").value,
    startTime: startTime,
    endTime: endTime,
    examTimeWindow: `${startTime}|${endTime}`
  };

  try {
    const res = await fetch("/api/admin/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Could not save configuration"));
      return;
    }
    showToast(`✅ Saved config & schedule (${startTime} - ${endTime}) for '${payload.subject}'!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error saving config: " + err.message);
  }
}

async function quickToggleExam(subject, newActiveState, existingTimeWindow) {
  try {
    const res = await fetch("/api/admin/toggle-exam", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subject,
        examActive: String(newActiveState),
        examTimeWindow: existingTimeWindow
      })
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Failed to toggle exam status"));
      return;
    }
    showToast(newActiveState
      ? `🟢 Opened '${subject}' for students!`
      : `🔴 Paused / Closed '${subject}' for students!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error toggling exam: " + err.message);
  }
}

async function handleAddQuestion(event) {
  event.preventDefault();
  const payload = {
    subject: document.getElementById("q-subject").value,
    questionText: document.getElementById("q-text").value.trim(),
    optionA: document.getElementById("q-opt-a").value.trim(),
    optionB: document.getElementById("q-opt-b").value.trim(),
    optionC: document.getElementById("q-opt-c").value.trim(),
    optionD: document.getElementById("q-opt-d").value.trim(),
    correctOptionIndex: document.getElementById("q-correct").value
  };

  try {
    const res = await fetch("/api/admin/question", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Could not add question"));
      return;
    }

    document.getElementById("q-text").value = "";
    document.getElementById("q-opt-a").value = "";
    document.getElementById("q-opt-b").value = "";
    document.getElementById("q-opt-c").value = "";
    document.getElementById("q-opt-d").value = "";
    showToast(`✅ Added new MCQ to '${payload.subject}' bank!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error adding question: " + err.message);
  }
}

async function unlockStudentAttempt(username, subject) {
  try {
    const res = await fetch("/api/admin/unlock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, subject })
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Could not unlock attempt"));
      return;
    }

    showToast(`🔓 Unlocked '${subject}' rewrite for student '${username}'!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error unlocking exam: " + err.message);
  }
}

async function handleUnlockAllSelectedSubject() {
  const subject = document.getElementById("bulk-unlock-subject").value;
  if (!subject) {
    showToast("⚠️ Please select a subject first.");
    return;
  }

  try {
    const res = await fetch("/api/admin/unlock-all", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject })
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Failed to unlock students"));
      return;
    }

    showToast(`🔓 Bulk Unlock Complete: Granted immediate re-access to ${data.unlockedCount} student attempt(s) for '${data.subject}'!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error during bulk unlock: " + err.message);
  }
}

async function handleGlobalUnlockAll() {
  try {
    const res = await fetch("/api/admin/unlock-all", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject: "ALL" })
    });
    const data = await res.json();
    if (!res.ok || data.error) {
      showToast("⚠️ " + (data.error || "Failed to unlock all students"));
      return;
    }

    showToast(`🌐 Global Unlock Complete: Granted immediate re-access to ${data.unlockedCount} locked student attempt(s) across ALL subjects!`);
    loadAdminData();
  } catch (err) {
    showToast("⚠️ Error during global unlock: " + err.message);
  }
}
